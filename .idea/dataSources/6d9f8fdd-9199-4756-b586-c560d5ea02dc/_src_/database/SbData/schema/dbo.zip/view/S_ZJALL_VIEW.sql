CREATE VIEW dbo.S_ZJALL_VIEW
AS
SELECT TOP 100 PERCENT dbo.S_ZJALL.领用单位号, dbo.s_dw_view.单位名称, 
      dbo.S_ZJALL.仪器编号, dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, 
      dbo.S_ZJALL.规格, dbo.S_ZJALL.单价, dbo.S_ZJALL.厂家, dbo.S_ZJALL.购置日期, 
      dbo.S_ZJALL.存放地名称, dbo.S_ZJALL.领用人, dbo.S_ZJALL.经手人, 
      dbo.S_ZJALL.记帐人, dbo.S_ZJALL.财务凭单, dbo.S_ZJALL.入库时间, 
      dbo.S_ZJALL.单据号, dbo.S_ZJALL.备注, dbo.S_ZJALL.设备号, dbo.S_ZJALL.科研号, 
      dbo.S_ZJALL.字符字段1, dbo.S_ZJALL.字符字段2, dbo.S_ZJALL.字符字段3, 
      dbo.S_ZJALL.字符字段4, dbo.S_ZJALL.字符字段5, dbo.S_ZJALL.数字字段1, 
      dbo.S_ZJALL.数字字段2, dbo.S_ZJALL.数字字段3, dbo.S_ZJALL.数字字段4, 
      dbo.S_ZJALL.存放地编号, dbo.S_ZJALL.国标分类号, dbo.S_ZJALL.分类号, 
      dbo.S_ZJALL.保修期限, dbo.S_ZJALL.国别, dbo.S_ZJALL.国别码, dbo.S_ZJALL.数量, 
      dbo.S_ZJALL.ID, dbo.S_ZJALL.人员编号, dbo.S_ZJALL.供货商, dbo.S_ZJALL.发票号, 
      dbo.S_ZJALL.计量单位, dbo.S_ZJALL.经费科目, dbo.S_ZJALL.使用方向, 
      dbo.S_ZJALL.设备来源, dbo.S_ZJALL.现状, dbo.S_ZJALL.国标分类名, 
      dbo.S_ZJALL.资产类别, dbo.S_ZJALL.采购形式, dbo.S_ZJALL.价值类型, 
      dbo.S_ZJALL.折旧方式, dbo.S_ZJALL.使用年限, dbo.S_ZJALL.累计折旧额, 
      dbo.S_ZJALL.折旧残值, dbo.S_ZJALL.净值, dbo.S_ZJALL.校区, 
      dbo.S_ZJALL.财务审核, dbo.S_ZJALL.财审核日期, dbo.S_ZJALL.财务审核人, 
      dbo.S_ZJALL.清查方式, dbo.S_ZJALL.清查日期, dbo.S_ZJALL.清查结果, 
      dbo.S_ZJALL.清查工号, dbo.S_ZJALL.清查人, dbo.S_ZJALL.清查备注, 
      dbo.s_dw_view.校单位编号, dbo.s_dw_view.校单位名称, dbo.s_dw_view.单位性质, 
      dbo.s_dw_view.单位性质名, dbo.s_dw_view.校单位性质, 
      dbo.s_dw_view.校单位性质名
FROM dbo.S_ZJALL LEFT OUTER JOIN
      dbo.s_dw_view ON dbo.S_ZJALL.领用单位号 = dbo.s_dw_view.单位编号
