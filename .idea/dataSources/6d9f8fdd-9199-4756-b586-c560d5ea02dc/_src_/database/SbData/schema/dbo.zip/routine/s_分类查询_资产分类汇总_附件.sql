create procedure s_分类查询_资产分类汇总_附件 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end
--删除临时表

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_在帐本期增加数_附件_gk') and type='u')
exec('drop table '+@yh+'temp_分类查询_在帐本期增加数_附件_gk')
else 
print '没有 '+@yh+'temp_分类查询_在帐本期增加数_附件_gk'

--目前在帐资产
--(非年末数)
exec('select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价) into '+@yh+'temp_分类查询_在帐本期增加数_附件_gk from S_FJ_DBF b,s_zjall a  where left(b.附件编号,8)=仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
union all
--主机本期入账，附件本期后入账
select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价)  from S_FJ_DBF b,s_zjall a  where left(b.附件编号,8)=仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
union all
--主机本期前入账，附件本期后入账，主机本期后减少
select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价)  from S_FJ_DBF b,s_bdk_dbf a  where left(b.附件编号,8)=仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间>'''+@jzrq+''' and a.变动日期>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') group by left(b.分类号,2)

')

