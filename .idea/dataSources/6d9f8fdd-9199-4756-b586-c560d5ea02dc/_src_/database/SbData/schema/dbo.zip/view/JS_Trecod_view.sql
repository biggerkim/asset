CREATE VIEW dbo.JS_Trecod_view
AS
SELECT dbo.JS_record.仪器编号, dbo.JS_record.上机日期, dbo.JS_record.上机时间, 
      dbo.JS_record.下机时间, dbo.JS_record.上机机时, dbo.JS_record.实验人数, 
      dbo.JS_record.上机机时 * dbo.JS_record.实验人数 AS 人时数, 
      dbo.JS_record.上机内容, dbo.JS_record.输入人, dbo.JS_record.输入日期, 
      dbo.JS_record.审核, dbo.JS_record.审核人, dbo.JS_record.审核日期, 
      dbo.JS_record.审核职工号, dbo.JS_record.ID, dbo.JS_record.单据号, 
      dbo.JS_record.实验者类别, dbo.s_syzlb.实验者类别名, dbo.s_syzlb.校编号, 
      dbo.s_syzlb.校名称, dbo.JS_record.输入职工号, dbo.S_ZJALL.领用单位号, 
      dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, dbo.S_ZJALL.规格, dbo.S_ZJALL.单价, 
      dbo.S_ZJALL.厂家, dbo.S_ZJALL.出厂号, dbo.S_ZJALL.购置日期, 
      dbo.S_ZJALL.存放地名称, dbo.S_ZJALL.领用人, dbo.S_ZJALL.入库时间, 
      dbo.S_ZJALL.备注, dbo.S_ZJALL.设备号, dbo.S_ZJALL.科研号, 
      dbo.S_ZJALL.字符字段1, dbo.S_ZJALL.字符字段2, dbo.S_ZJALL.字符字段3, 
      dbo.S_ZJALL.字符字段4, dbo.S_ZJALL.字符字段5, dbo.S_ZJALL.数字字段1, 
      dbo.S_ZJALL.数字字段2, dbo.S_ZJALL.数字字段3, dbo.S_ZJALL.数字字段4
FROM dbo.JS_record LEFT OUTER JOIN
      dbo.s_syzlb ON dbo.JS_record.实验者类别 = dbo.s_syzlb.code LEFT OUTER JOIN
      dbo.S_ZJALL ON dbo.JS_record.仪器编号 = dbo.S_ZJALL.仪器编号
