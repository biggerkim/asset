
CREATE VIEW dbo.s_jzlx
AS
SELECT TOP 100 PERCENT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) 
      AS 价值类型名, 校编号 AS 校价值类型, 校名称 AS 校价值类型名
FROM dbo.MK1
WHERE (BJ = '价值类型')
ORDER BY NR

