CREATE VIEW dbo.S_SYFX
AS
SELECT TOP 100 PERCENT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) 
      AS 使用方向名, 校编号 AS 校使用方向, 校名称 AS 校使用方向名
FROM dbo.MK1
WHERE (BJ = '使用方向')
ORDER BY LEFT(NR, 1)
