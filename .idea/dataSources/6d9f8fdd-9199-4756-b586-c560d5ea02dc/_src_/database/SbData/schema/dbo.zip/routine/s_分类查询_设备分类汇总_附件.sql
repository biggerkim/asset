



create procedure s_分类查询_设备分类汇总_附件 @qsrq varchar(20), @jzrq varchar(20),@lydw varchar(10),@yh varchar(50),@condition varchar(100)
as
if @lydw='00'
begin
set @lydw=''
end
--删除临时表

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_在帐本期增加数_附件') and type='u')
exec('drop table '+@yh+'temp_分类查询_在帐本期增加数_附件')
else 
print '没有 '+@yh+'temp_分类查询_在帐本期增加数_附件'

if exists(select 1 from sysobjects where name = 'temp_分类查询_在帐本期增加数_附件') 
drop table temp_分类查询_在帐本期增加数_附件
else 
print '没有 temp_分类查询_在帐本期增加数_附件'

--目前在帐设备
--主机本期前入账，附件本期后入账
exec('select * into '+@yh+'temp_分类查询_在帐本期增加数_附件 from (
--目前在帐设备
--附件本期入账
select 分类号=left(b.分类号,2),总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
--减少
select 分类号=left(b.分类号,2),总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 <'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and  b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
--内部转移(附件入库时间<主机变动日期)
select 分类号=left(b.分类号,2),总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
select 领用单位号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
--***************
--目前在帐设备
--附件本期入账
union all
select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 >'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
--减少
select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 >'''+@jzrq+''' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and  b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
--内部转移(附件入库时间<主机变动日期)
select 分类号=left(b.分类号,2),总数量=0,总价=-sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 >'''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
union all
select 分类号=left(b.分类号,2),总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 > '''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by left(b.分类号,2)
) c
')




