CREATE VIEW dbo.t_record_view
AS
SELECT dbo.t_record.领用单位号, dbo.S_DW.单位名称, 
      dbo.t_record.仪器编号 AS 资产编号, dbo.t_record.仪器名称 AS 资产名称, 
      dbo.t_record.型号, dbo.t_record.规格, dbo.t_record.购置日期, dbo.t_record.领用人, 
      dbo.t_record.调剂类别, dbo.t_record.调剂标志, dbo.s_tjbz.调剂标志名, 
      dbo.t_record.调剂申请日, dbo.t_record.调剂申请人, dbo.t_record.调剂人编号, 
      dbo.t_record.调剂原因, dbo.t_record.审核人, dbo.t_record.审核日期, 
      dbo.t_record.申请人, dbo.t_record.申请日期, dbo.t_record.联系方式, 
      dbo.t_record.调剂日期, dbo.t_record.单价, dbo.t_record.数量, dbo.t_record.金额, 
      dbo.t_record.计量单位, dbo.t_record.厂家, dbo.t_record.出厂号, 
      dbo.t_record.出厂日期, dbo.t_record.现状, dbo.S_XZ.现状名, dbo.t_record.经费科目, 
      dbo.S_JFKM.经费科目名, dbo.t_record.使用方向, dbo.S_SYFX.使用方向名, 
      dbo.t_record.设备来源 AS 资产来源, dbo.S_SBLY.设备来源名 AS 资产来源名, 
      dbo.t_record.存放地名称, dbo.t_record.人员编号, dbo.t_record.备注, 
      dbo.t_record.设备号 AS 资产号, dbo.t_record.科研号, dbo.t_record.字符字段1, 
      dbo.t_record.字符字段2, dbo.t_record.字符字段3, dbo.t_record.字符字段4, 
      dbo.t_record.字符字段5, dbo.t_record.数字字段1, dbo.t_record.数字字段2, 
      dbo.t_record.数字字段3, dbo.t_record.存放地编号, dbo.t_record.国标分类号, 
      dbo.t_record.国标分类名, dbo.t_record.分类号, dbo.t_record.保修期限, 
      dbo.t_record.国别, dbo.t_record.国别码, dbo.t_record.数字字段4, 
      dbo.t_record.资产类别, dbo.s_zclb.资产类别名, dbo.t_record.校区, dbo.s_xq.校区名, 
      dbo.t_record.图片文件, dbo.t_record.图文名称, dbo.t_record.图片文件1, 
      dbo.t_record.图文名称1, dbo.t_record.图片文件2, dbo.t_record.图文名称2, 
      dbo.t_record.图文名称3, dbo.t_record.图片文件3, dbo.t_record.六类资产, 
      dbo.t_record.字符字段6, dbo.t_record.字符字段7, dbo.t_record.字符字段8, 
      dbo.t_record.字符字段9, dbo.t_record.字符字段10, dbo.t_record.日期字段1, 
      dbo.t_record.日期字段2, dbo.t_record.代码字段1, dbo.t_record.代码字段2, 
      dbo.t_record.代码字段3, dbo.t_record.ID, dbo.t_record.字符字段11, 
      dbo.t_record.字符字段12, dbo.t_record.字符字段13, dbo.t_record.字符字段14, 
      dbo.t_record.字符字段15, dbo.t_record.字符字段16, dbo.t_record.数字字段5, 
      dbo.t_record.数字字段6, dbo.t_record.数字字段7, dbo.t_record.数字字段8, 
      dbo.t_record.变动原因, dbo.t_record.变动单据号, dbo.t_record.调剂单据号
FROM dbo.t_record LEFT OUTER JOIN
      dbo.s_tjbz ON dbo.t_record.调剂标志 = dbo.s_tjbz.code LEFT OUTER JOIN
      dbo.S_DW ON dbo.t_record.领用单位号 = dbo.S_DW.单位编号 LEFT OUTER JOIN
      dbo.S_XZ ON dbo.t_record.现状 = dbo.S_XZ.code LEFT OUTER JOIN
      dbo.S_JFKM ON dbo.t_record.经费科目 = dbo.S_JFKM.code LEFT OUTER JOIN
      dbo.S_SYFX ON dbo.t_record.使用方向 = dbo.S_SYFX.code LEFT OUTER JOIN
      dbo.S_SBLY ON dbo.t_record.设备来源 = dbo.S_SBLY.code LEFT OUTER JOIN
      dbo.s_zclb ON dbo.t_record.资产类别 = dbo.s_zclb.code LEFT OUTER JOIN
      dbo.s_xq ON dbo.t_record.校区 = dbo.s_xq.code
