CREATE VIEW dbo.S_SBLY
AS
SELECT TOP 100 PERCENT BJ, NR, LEFT(NR, 1) AS code, RIGHT(LEFT(NR, 10), 8) 
      AS 设备来源名, 校编号 AS 校设备来源, 校名称 AS 校设备来源名
FROM dbo.MK1
WHERE (BJ = '设备来源')
ORDER BY LEFT(NR, 1)
