
CREATE VIEW dbo.s_syfx_mk1_view
AS
SELECT 校编号 AS 校使用编号, 校名称 AS 使用方向名, BJ, LEFT(NR, 1) 
      AS syfx_code
FROM dbo.MK1
WHERE (BJ = '使用方向')

