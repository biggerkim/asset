


CREATE procedure s_资产情况表_按11大类 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50),@condition varchar(100)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_资产情况表_按11大类_s_zjall') and type='u')
exec('drop table '+@yh+'temp_资产情况表_按11大类_s_zjall')
else 
print '没有 '+@yh+'temp_资产情况表_按11大类_s_zjall'

if exists(select 1 from sysobjects where name = 'temp_资产情况表_按11大类_s_zjall') 
drop table temp_资产情况表_按11大类_s_zjall
else 
print '没有 temp_资产情况表_按11大类_s_zjall'
--***************
--测试用例
--declare @qsrq varchar(30),@jzrq varchar(30),@lydw varchar(10),@yh varchar(50)
--set @qsrq='1900-01-01'
--set @jzrq='2010-12-31'
--set @lydw=''
--set @yh='管理员'
--exec('drop table '+@yh+'temp_资产情况表_按11大类_s_zjall')
--**************

exec('select * into '+@yh+'temp_资产情况表_按11大类_s_zjall from (
--目前在帐设备
--(年末数)
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,单位标

志=''*'' from s_zjall where 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--本期在帐数(非年末数，本期增加)
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,单位标志

=''*'' from s_zjall where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类

号,2),国标分类号,现状,单价 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,单位标

志=''*'' from s_bdk_dbf where 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状

=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期增加数

select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zj'',总数量=count(*),总价=sum(单价),单价=单价,单位

标志=''*'' from s_bdk_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状

=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期减少数

select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,单位标志

=''*'' from s_bdk_dbf where 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状

=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价
union all
--目前变动库里的增减值资产
--（年末数）
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=0,总价=-sum(变动单价),单价=0,单位标志

=''*'' from s_bdk_dbf where  入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 and '+@condition+' group 

by left(国标分类号,2),国标分类号,单价
union all
--（非年末数）本期增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zz'',总数量=0,总价=sum(变动单价),单价=0,单位标志

=''*'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group 

by left(国标分类号,2),国标分类号,单价
--（非年末数）本期减值数
union all
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''jz'',总数量=0,总价=-sum(变动单价),单价=0,单位标志

=''*'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 and '+@condition+' group 

by left(国标分类号,2),国标分类号,单价
union all
--本期增加数里减值数
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bj'',总数量=0,总价=-sum(变动单价),单价=0,单位标志

=''*'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价

<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

union all
--本期增加数里增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bz'',总数量=0,总价=sum(变动单价),单价=0,单位标志

=''*'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价

>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

) b')

--报表输出条件
--土地  序列1=10 
--办公用地 序列2 =11 
--业务用地 序列2 =12 
--其他用地 序列2 =13 
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''10'' where 国标分类号=''01''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''11'' where 序列1=''10'' and left(国标分类号0,4)=''0131''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''12'' where 序列1=''10'' and (left(国标分类号0,4)=''0132'' or left(国标分类号0,4)=''0133'' or 

left(国标分类号0,4)=''0139'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''13'' where 序列1=''10'' and 序列2<>''11'' and 序列2<>''12''')
--房屋及构筑物  序列1=20 
--办公用房  序列2=21 
--业务用房  序列2=22 
--其它  序列2=23
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''20'' where (国标分类号=''02'' or 国标分类号=''03'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''21'' where 序列1=''20'' and (left(国标分类号0,3)=''022'' or left(国标分类号0,3)=''024'' or 

left(国标分类号0,3)=''025'' or left(国标分类号0,3)=''026'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''22'' where 序列1=''20'' and (left(国标分类号0,3)=''028'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''23'' where 序列1=''20'' and 序列2<>''21'' and 序列2<>''22''')
--通用设备 序列1=30
--单价20万元（不含）以下 序列2=31
--单价20万元（含）以上50万元以下 序列2=32
--单价50万元（含）以上100万元以下 序列2=33
--单价100万元（含）以上200万元以下 序列2=34
--单价200万元（含）以上 序列2=35

exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''30'' where (国标分类号 between ''06'' and ''21'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''31'' where 序列1=''30'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''32'' where 序列1=''30'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''33'' where 序列1=''30'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''34'' where 序列1=''30'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''35'' where 序列1=''30'' and 单价>=2000000')
--专用设备 序列1=40
--单价20万元（不含）以下 序列2=41
--单价20万元（含）以上50万元以下 序列2=42
--单价50万元（含）以上100万元以下 序列2=43
--单价100万元（含）以上200万元以下 序列2=44
--单价200万元（含）以上 序列2=45
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''40'' where (国标分类号 between ''25'' and ''47'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''41'' where 序列1=''40'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''42'' where 序列1=''40'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''43'' where 序列1=''40'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''44'' where 序列1=''40'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''45'' where 序列1=''40'' and 单价>=2000000')
--交通运输设备 序列1=50
--轿车 序列2=51
--载客汽车 序列2=52
--专用汽车 序列2=53
--其他汽车 序列2=54
--其他运输工具 序列2=55
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''50'' where (国标分类号 between ''52'' and ''56'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''51'' where 序列1=''50'' and left(国标分类号0,4)=''5316''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''52'' where 序列1=''50'' and left(国标分类号0,4)=''5315''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''53'' where 序列1=''50'' and left(国标分类号0,4)=''5317''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''54'' where 序列1=''50'' and left(国标分类号0,3)=''531'' and 序列2<>''51'' and 序列2<>''52'' 

and 序列2<>''53''')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''55'' where (国标分类号 between ''52'' and ''56'' and 序列2<>''51'' and 序列2<>''52'' and 序

列2<>''53'' and 序列2<>''54'' and 序列2<>''55'')')
--电器设备 序列1=60
--单价20万元（不含）以下 序列2=61
--单价20万元（含）以上50万元以下 序列2=62
--单价50万元（含）以上100万元以下 序列2=63
--单价100万元（含）以上200万元以下 序列2=64
--单价200万元（含）以上 序列2=65
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''60'' where (国标分类号 between ''60'' and ''65'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''61'' where 序列1=''60'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''62'' where 序列1=''60'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''63'' where 序列1=''60'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''64'' where 序列1=''60'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''65'' where 序列1=''60'' and 单价>=2000000')
--电子产品及通讯设备 序列1=70
--单价20万元（不含）以下 序列2=71
--单价20万元（含）以上50万元以下 序列2=72
--单价50万元（含）以上100万元以下 序列2=73
--单价100万元（含）以上200万元以下 序列2=74
--单价200万元（含）以上 序列2=75
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''70'' where (国标分类号 between ''68'' and ''71'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''71'' where 序列1=''70'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''72'' where 序列1=''70'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''73'' where 序列1=''70'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''74'' where 序列1=''70'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''75'' where 序列1=''70'' and 单价>=2000000')
--仪器仪表、计量标准器具及量具、衡器 序列1=80
--单价20万元（不含）以下 序列2=81
--单价20万元（含）以上50万元以下 序列2=82
--单价50万元（含）以上100万元以下 序列2=83
--单价100万元（含）以上200万元以下 序列2=84
--单价200万元（含）以上 序列2=85
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''80'' where (国标分类号 between ''74'' and ''77'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''81'' where 序列1=''80'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''82'' where 序列1=''80'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''83'' where 序列1=''80'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''84'' where 序列1=''80'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''85'' where 序列1=''80'' and 单价>=2000000')
--文艺体育设备 序列1=90
--单价20万元（不含）以下 序列2=91
--单价20万元（含）以上50万元以下 序列2=92
--单价50万元（含）以上100万元以下 序列2=93
--单价100万元（含）以上200万元以下 序列2=94
--单价200万元（含）以上 序列2=95
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''90'' where (国标分类号 between ''80'' and ''82'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''91'' where 序列1=''90'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''92'' where 序列1=''90'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''93'' where 序列1=''90'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''94'' where 序列1=''90'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''95'' where 序列1=''90'' and 单价>=2000000')
--图书文物及陈列品 序列1=A0
--单价20万元（不含）以下 序列2=A1
--单价20万元（含）以上50万元以下 序列2=A2
--单价50万元（含）以上100万元以下 序列2=A3
--单价100万元（含）以上200万元以下 序列2=A4
--单价200万元（含）以上 序列2=A5
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''A0'' where (国标分类号 between ''85'' and ''87'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''A1'' where 序列1=''A0'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''A2'' where 序列1=''A0'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''A3'' where 序列1=''A0'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''A4'' where 序列1=''A0'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''A5'' where 序列1=''A0'' and 单价>=2000000')
--家具用具及其他类 序列1=B0
--单价20万元（不含）以下 序列2=B1
--单价20万元（含）以上50万元以下 序列2=B2
--单价50万元（含）以上100万元以下 序列2=B3
--单价100万元（含）以上200万元以下 序列2=B4
--单价200万元（含）以上 序列2=B5
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列1=''B0'' where (国标分类号 between ''90'' and ''92'')')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''B1'' where 序列1=''B0'' and 单价<200000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''B2'' where 序列1=''B0'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''B3'' where 序列1=''B0'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''B4'' where 序列1=''B0'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产情况表_按11大类_s_zjall set 序列2=''B5'' where 序列1=''B0'' and 单价>=2000000')
if exists(select 1 from sysobjects where id = object_id(@yh+'资产情况表_按11大类') and type='u')
begin
exec('drop table '+@yh+'资产情况表_按11大类')
end

if exists(select 1 from sysobjects where name = '资产情况表_按11大类') 
begin
drop table 资产情况表_按11大类
end
create table 资产情况表_按11大类(xh int,m1 varchar(40),m2 varchar(4),sl_1 int default 0,je_1 numeric(14,2)  default 0.00,sl_2 int default 0,je_2 numeric

(14,2) default 0,sl_3 int default 0,je_3 numeric(14,2) default 0,sl_4 int default 0,je_4 numeric(14,2) default 0,sl_5 int default 0,je_5 numeric(14,2) 

default 0,sl_6 int default 0,je_6 numeric(14,2) default 0,sl_7 int default 0,je_7 numeric(14,2) default 0,sl_8 int default 0,je_8 numeric(14,2) default 

0,sl_9 int default 0,je_9 numeric(14,2) default 0,sl_A int default 0,je_A numeric(14,2) default 0,sl_B int default 0,je_B numeric(14,2) default 0,sl_C int 

default 0,je_C numeric(14,2) default 0,sl_D int default 0,je_D numeric(14,2) default 0,sl_E int default 0,je_E numeric(14,2) default 0,sl_F int default 

0,je_F numeric(14,2) default 0,sl_G int default 0,je_G numeric(14,2) default 0,sl_H int default 0,je_H numeric(14,2) default 0,sl_I int default 0,je_I 

numeric(14,2) default 0,sl_J int default 0,je_J numeric(14,2) default 0,sl_P int default 0,je_P numeric(14,2) default 0,
sl_Q int default 0,je_Q numeric(14,2) default 0,sl_R int default 0,je_R numeric(14,2) default 0,sl_S int default 0,je_S numeric(14,2) default 0,sl_T int 

default 0,je_T numeric(14,2) default 0,sl_U int default 0,je_U numeric(14,2) default 0,sl_V int default 0,je_V numeric(14,2) default 0,sl_W int default 

0,je_W numeric(14,2) default 0,sl_X int default 0,je_X numeric(14,2) default 0,
sl_@ int default 0,je_@ numeric(14,2) default 0,sl_zj int default 0,je_zj numeric(14,2) default 0,
sl_zz int default 0,je_zz numeric(14,2) default 0,sl_jz int default 0,je_jz numeric(14,2) default 0,
sl_bj int default 0,je_bj numeric(14,2) default 0,sl_bz int default 0,je_bz numeric(14,2) default 0
)
insert into 资产情况表_按11大类(xh,m1,m2) values(1,'总金额','00')
insert into 资产情况表_按11大类(xh,m1,m2) values(2,'(一)土地','10')
insert into 资产情况表_按11大类(xh,m1,m2) values(3,'1.办公用地','11')
insert into 资产情况表_按11大类(xh,m1,m2) values(4,'2.业务用地','12')
insert into 资产情况表_按11大类(xh,m1,m2) values(5,'3.其他','13')
insert into 资产情况表_按11大类(xh,m1,m2) values(6,'(二)房屋及构筑物','20')
insert into 资产情况表_按11大类(xh,m1,m2) values(7,'1.办公用房','21')
insert into 资产情况表_按11大类(xh,m1,m2) values(8,'2.业务用房','22')
insert into 资产情况表_按11大类(xh,m1,m2) values(9,'3.其他','23')
insert into 资产情况表_按11大类(xh,m1,m2) values(10,'(三)通用设备','30')
insert into 资产情况表_按11大类(xh,m1,m2) values(11,'1.单价20万元（不含）以下','31')
insert into 资产情况表_按11大类(xh,m1,m2) values(12,'2.单价20万元（含）-50万元','32')
insert into 资产情况表_按11大类(xh,m1,m2) values(13,'3.单价50万元（含）-100万元','33')
insert into 资产情况表_按11大类(xh,m1,m2) values(14,'4.单价100万元（含）-200万元','34')
insert into 资产情况表_按11大类(xh,m1,m2) values(15,'5.单价200万元（含）以上','35')
insert into 资产情况表_按11大类(xh,m1,m2) values(16,'(四)专用设备','40')
insert into 资产情况表_按11大类(xh,m1,m2) values(17,'1.单价20万元（不含）以下','41')
insert into 资产情况表_按11大类(xh,m1,m2) values(18,'2.单价20万元（含）-50万元','42')
insert into 资产情况表_按11大类(xh,m1,m2) values(19,'3.单价50万元（含）-100万元','43')
insert into 资产情况表_按11大类(xh,m1,m2) values(20,'4.单价100万元（含）-200万元','44')
insert into 资产情况表_按11大类(xh,m1,m2) values(21,'5.单价200万元（含）以上','45')
insert into 资产情况表_按11大类(xh,m1,m2) values(22,'(五)交通运输设备','50')
insert into 资产情况表_按11大类(xh,m1,m2) values(23,'1.轿车','51')
insert into 资产情况表_按11大类(xh,m1,m2) values(24,'2.载客汽车','52')
insert into 资产情况表_按11大类(xh,m1,m2) values(25,'3.专用汽车','53')
insert into 资产情况表_按11大类(xh,m1,m2) values(26,'4.其他汽车','54')
insert into 资产情况表_按11大类(xh,m1,m2) values(27,'5.其他运输工具','55')
insert into 资产情况表_按11大类(xh,m1,m2) values(28,'(六)电器设备','60')
insert into 资产情况表_按11大类(xh,m1,m2) values(29,'1.单价20万元（不含）以下','61')
insert into 资产情况表_按11大类(xh,m1,m2) values(30,'2.单价20万元（含）-50万元','62')
insert into 资产情况表_按11大类(xh,m1,m2) values(31,'3.单价50万元（含）-100万元','63')
insert into 资产情况表_按11大类(xh,m1,m2) values(32,'4.单价100万元（含）-200万元','64')
insert into 资产情况表_按11大类(xh,m1,m2) values(33,'5.单价200万元（含）以上','65')
insert into 资产情况表_按11大类(xh,m1,m2) values(34,'(七)电子产品及通讯设备','70')
insert into 资产情况表_按11大类(xh,m1,m2) values(35,'1.单价20万元（不含）以下','71')
insert into 资产情况表_按11大类(xh,m1,m2) values(36,'2.单价20万元（含）-50万元','72')
insert into 资产情况表_按11大类(xh,m1,m2) values(37,'3.单价50万元（含）-100万元','73')
insert into 资产情况表_按11大类(xh,m1,m2) values(38,'4.单价100万元（含）-200万元','74')
insert into 资产情况表_按11大类(xh,m1,m2) values(39,'5.单价200万元（含）以上','75')
insert into 资产情况表_按11大类(xh,m1,m2) values(40,'(八)仪器仪表、计量标准器具及量具、衡器','80')
insert into 资产情况表_按11大类(xh,m1,m2) values(41,'1.单价20万元（不含）以下','81')
insert into 资产情况表_按11大类(xh,m1,m2) values(42,'2.单价20万元（含）-50万元','82')
insert into 资产情况表_按11大类(xh,m1,m2) values(43,'3.单价50万元（含）-100万元','83')
insert into 资产情况表_按11大类(xh,m1,m2) values(44,'4.单价100万元（含）-200万元','84')
insert into 资产情况表_按11大类(xh,m1,m2) values(45,'5.单价200万元（含）以上','85')
insert into 资产情况表_按11大类(xh,m1,m2) values(46,'(九)文艺体育设备','90')
insert into 资产情况表_按11大类(xh,m1,m2) values(47,'1.单价20万元（不含）以下','91')
insert into 资产情况表_按11大类(xh,m1,m2) values(48,'2.单价20万元（含）-50万元','92')
insert into 资产情况表_按11大类(xh,m1,m2) values(49,'3.单价50万元（含）-100万元','93')
insert into 资产情况表_按11大类(xh,m1,m2) values(50,'4.单价100万元（含）-200万元','94')
insert into 资产情况表_按11大类(xh,m1,m2) values(51,'5.单价200万元（含）以上','95')
insert into 资产情况表_按11大类(xh,m1,m2) values(52,'(十)图书文物及陈列品','A0')
insert into 资产情况表_按11大类(xh,m1,m2) values(53,'1.单价20万元（不含）以下','A1')
insert into 资产情况表_按11大类(xh,m1,m2) values(54,'2.单价20万元（含）-50万元','A2')
insert into 资产情况表_按11大类(xh,m1,m2) values(55,'3.单价50万元（含）-100万元','A3')
insert into 资产情况表_按11大类(xh,m1,m2) values(56,'4.单价100万元（含）-200万元','A4')
insert into 资产情况表_按11大类(xh,m1,m2) values(57,'5.单价200万元（含）以上','A5')
insert into 资产情况表_按11大类(xh,m1,m2) values(58,'(十一)家具用具及其他类','B0')
insert into 资产情况表_按11大类(xh,m1,m2) values(59,'1.单价20万元（不含）以下','B1')
insert into 资产情况表_按11大类(xh,m1,m2) values(60,'2.单价20万元（含）-50万元','B2')
insert into 资产情况表_按11大类(xh,m1,m2) values(61,'3.单价50万元（含）-100万元','B3')
insert into 资产情况表_按11大类(xh,m1,m2) values(62,'4.单价100万元（含）-200万元','B4')
insert into 资产情况表_按11大类(xh,m1,m2) values(63,'5.单价200万元（含）以上','B5')
if exists(select 1 from sysobjects where name = 'temp_资产情况表_按11大类') 
begin
drop table temp_资产情况表_按11大类
end
exec('select 序列1,序列2,现状,总价=sum(总价),总数量=sum(总数量) into temp_资产情况表_按11大类 from '+@yh+'temp_资产情况表_按11大类_s_zjall group by 序列1,序

列2,现状')
declare @xl1 varchar(4),@xl2 varchar(4),@zj numeric(14,2),@zsl int,@xz varchar(4)
while (select count(*) from temp_资产情况表_按11大类)>0
begin
select top 1 @xl1=序列1,@xl2=序列2,@xz=现状,@zj=总价,@zsl=总数量 from temp_资产情况表_按11大类
if @xz='1'
begin
update 资产情况表_按11大类 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2='00'
end
else if @xz='2'
begin
update 资产情况表_按11大类 set sl_2=sl_@+@zsl,je_2=je_2+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_2=sl_@+@zsl,je_2=je_2+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2='00'
end
else if @xz='3'
begin
update 资产情况表_按11大类 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2='00'
end
else if @xz='4'
begin
update 资产情况表_按11大类 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2='00'
end
else if @xz='5'
begin
update 资产情况表_按11大类 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2='00'end
else if @xz='6'
begin
update 资产情况表_按11大类 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2='00'
end
else if @xz='7'
begin
update 资产情况表_按11大类 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2='00'
end
else if @xz='8'
begin
update 资产情况表_按11大类 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2='00'
end
else if @xz='9'
begin
update 资产情况表_按11大类 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2='00'
end
else if @xz='A'
begin
update 资产情况表_按11大类 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2='00'
end
else if @xz='B'
begin
update 资产情况表_按11大类 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2='00'
end
else if @xz='C'
begin
update 资产情况表_按11大类 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2='00'
end
else if @xz='D'
begin
update 资产情况表_按11大类 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2='00'
end
else if @xz='E'
begin
update 资产情况表_按11大类 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2='00'
end
else if @xz='F'
begin
update 资产情况表_按11大类 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2='00'
end
else if @xz='G'
begin
update 资产情况表_按11大类 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2='00'
end
else if @xz='H'
begin
update 资产情况表_按11大类 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2='00'
end
else if @xz='I'
begin
update 资产情况表_按11大类 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2='00'
end
else if @xz='J'
begin
update 资产情况表_按11大类 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2='00'
end
else if @xz='P'
begin
update 资产情况表_按11大类 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2='00'
end
else if @xz='Q'
begin
update 资产情况表_按11大类 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2='00'
end
else if @xz='R'
begin
update 资产情况表_按11大类 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2='00'
end
else if @xz='S'
begin
update 资产情况表_按11大类 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2='00'
end
else if @xz='T'
begin
update 资产情况表_按11大类 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2='00'
end
else if @xz='U'
begin
update 资产情况表_按11大类 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2='00'
end
else if @xz='V'
begin
update 资产情况表_按11大类 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2='00'
end
else if @xz='W'
begin
update 资产情况表_按11大类 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2='00'
end
else if @xz='X'
begin
update 资产情况表_按11大类 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2='00'
end
else if @xz='@'
begin
update 资产情况表_按11大类 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2='00'
end
else if @xz='zj'
begin
update 资产情况表_按11大类 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2='00'
end
else if @xz='zz'
begin
update 资产情况表_按11大类 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2='00'
end
else if @xz='jz'
begin
update 资产情况表_按11大类 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2='00'
end
else if @xz='bj'
begin
update 资产情况表_按11大类 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2='00'
end
else if @xz='bz'
begin
update 资产情况表_按11大类 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl2
update 资产情况表_按11大类 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl1
update 资产情况表_按11大类 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2='00'
end
else
print '现状有异常'

delete from temp_资产情况表_按11大类 where 序列2=@xl2 and 现状=@xz and 总价=@zj and 总数量=@zsl
end
drop table temp_资产情况表_按11大类
exec('drop table '+@yh+'temp_资产情况表_按11大类_s_zjall')


