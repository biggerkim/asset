
create procedure del_资产概况临时表 @table varchar(200)
as
exec('drop table '+@table+'')
