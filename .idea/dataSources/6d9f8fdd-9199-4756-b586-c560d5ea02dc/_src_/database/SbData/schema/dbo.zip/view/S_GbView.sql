Create view S_GbView(国别码,国别) as select s_gb.dm,s_gb.mz from s_gb
