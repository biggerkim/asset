create procedure s_分类查询统计表_附件_gk11 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end
--删除临时表

if exists(select 1 from sysobjects where id = object_id(@yh+'分类查询统计表_附件_gk11_last') and type='u')
exec('drop table '+@yh+'分类查询统计表_附件_gk11_last')
else 
print '没有 '+@yh+'分类查询统计表_附件_gk11_last'


--目前在帐资产
--(非年末数)
exec('select 分类名称=''aaaaaaaaaabbbbbbbbbbccccccccccdddddddddd'',国标分类号=国标分类号,总数量=0,总价=sum(总价) into '+@yh+'分类查询统计表_附件_gk11 from (
select 国标分类号=left(国标分类号,2),总数量=0,总价=sum(附件单价)  from s_fj_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(国标分类号,2)) b group by 国标分类号')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''土地'',国标分类号=''01'' where 国标分类号=''01''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''房屋及构筑物'',国标分类号=''02'' where 国标分类号=''02'' or 国标分类号=''03''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''通用设备'',国标分类号=''03'' where 国标分类号>=''06'' and 国标分类号<=''21''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''专用设备'',国标分类号=''04'' where 国标分类号>=''25'' and 国标分类号<=''47''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''交通运输设备'',国标分类号=''05'' where 国标分类号>=''52'' and 国标分类号<=''56''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''电气设备'',国标分类号=''06'' where 国标分类号>=''60'' and 国标分类号<=''65''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''电子产品及通信设备'',国标分类号=''07'' where 国标分类号>=''68'' and 国标分类号<=''71''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''仪器仪表、计量标准器具及量具、衡器'',国标分类号=''08'' where 国标分类号>=''74'' and 国标分类号<=''77''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''文艺体育设备'',国标分类号=''09'' where 国标分类号>=''80'' and 国标分类号<=''82''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''图书文物及陈列品'',国标分类号=''10'' where 国标分类号>=''85'' and 国标分类号<=''87''')
exec('update '+@yh+'分类查询统计表_附件_gk11 set 分类名称=''家具用具及其他类'',国标分类号=''11'' where 国标分类号>=''90'' and 国标分类号<=''92''')
exec('select 分类名称,国标分类号,总数量=sum(总数量),总价=sum(总价) into '+@yh+'分类查询统计表_附件_gk11_last from '+@yh+'分类查询统计表_附件_gk11 group by 分类名称,国标分类号')
if exists(select 1 from sysobjects where id = object_id(@yh+'分类查询统计表_附件_gk11') and type='u')
exec('drop table '+@yh+'分类查询统计表_附件_gk11')
else 
print '没有 '+@yh+'分类查询统计表_附件_gk11'


