create procedure s_资产分类增减变动统计表_附件_flybgk @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类增减变动统计表_附件_flybgk_s_fj_dbf') and type='u')
exec('drop table '+@yh+'temp_分类增减变动统计表_附件_flybgk_s_fj_dbf')
else 
print '没有 '+@yh+'temp_分类增减变动统计表_附件_flybgk_s_fj_dbf'


--***************
--测试用例
--declare @qsrq varchar(30),@jzrq varchar(30),@lydw varchar(10),@yh varchar(50)
--set @qsrq='1900-01-01'
--set @jzrq='2010-12-31'
--set @lydw=''
--set @yh='管理员'
--exec('drop table '+@yh+'temp_分类增减变动统计表_附件_flybgk_s_fj_dbf')
--**************
exec('select * into '+@yh+'temp_分类增减变动统计表_附件_flybgk_s_fj_dbf from (
--目前在帐资产
--(年末数)
select 分类号=left(分类号,2),现状=''@'',使用方向,总数量=0,总价=sum(附件单价),单位标志=''*'',类别=''shb'' from s_fj_dbf where 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(分类号,2),使用方向
union all
--本期在帐数(非年末数，本期增加)
select 分类号=left(分类号,2),现状,使用方向,总数量=0,总价=sum(附件单价),单位标志=''*'',类别=''shb'' from s_fj_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(分类号,2),现状,使用方向 
) b')
--**************************************************

