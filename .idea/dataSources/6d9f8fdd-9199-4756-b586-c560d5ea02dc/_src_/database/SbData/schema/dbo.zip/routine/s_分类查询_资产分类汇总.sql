create procedure s_分类查询_资产分类汇总 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end
--删除临时表

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_在帐本期增加数_gk') and type='u')
exec('drop table '+@yh+'temp_分类查询_在帐本期增加数_gk')
else 
print '没有 '+@yh+'temp_分类查询_在帐本期增加数_gk'



if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_变动本期增加数_gk') and type='u')
exec('drop table '+@yh+'temp_分类查询_变动本期增加数_gk')
else 
print '没有 '+@yh+'temp_分类查询_变动本期增加数_gk'



if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_本期后增减值数_gk') and type='u')
exec('drop table '+@yh+'temp_分类查询_本期后增减值数_gk')
else 
print '没有 '+@yh+'temp_分类查询_本期后增减值数_gk'




--目前在帐资产
--(非年末数)
exec('select 分类号=left(分类号,2),总数量=count(*),总价=sum(单价) into '+@yh+'temp_分类查询_在帐本期增加数_gk from s_zjall where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(分类号,2) order by left(分类号,2)')
--目前变动库里的非增减值
--本期增加本期变动（非增减值）本期增加数
exec('select 分类号=left(分类号,2),总数量=count(*),总价=sum(单价) into '+@yh+'temp_分类查询_变动本期增加数_gk from s_bdk_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') group by left(分类号,2) order by left(分类号,2)')
--目前变动库里的增值资产
--（非年末数）本期增加数
exec('select 分类号=left(分类号,2),总数量=0,变动总价=sum(变动单价) into '+@yh+'temp_分类查询_本期后增减值数_gk from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 group by left(分类号,2) order by left(分类号,2)')

