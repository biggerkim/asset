CREATE VIEW dbo.s_bjprdbd_dbf_L
AS
SELECT dbo.s_syfx_mk1_view.校使用编号, dbo.s_syfx_mk1_view.使用方向名, 
      dbo.s_sbly_mk1_view.设备来源名, dbo.s_sbly_mk1_view.校设源编号, 
      dbo.s_jfkm_mk1_view.校经费编号, dbo.s_jfkm_mk1_view.经费科目名, 
      dbo.s_xz_mk1_view.校现状编号, dbo.s_xz_mk1_view.现状名, 
      dbo.S_DW.校单位编号, dbo.S_DW.校单位名称, dbo.S_BDK_DBF.*
FROM dbo.s_jfkm_mk1_view LEFT OUTER JOIN
      dbo.S_DW LEFT OUTER JOIN
      dbo.S_BDK_DBF ON 
      dbo.S_DW.单位编号 = dbo.S_BDK_DBF.领用单位号 LEFT OUTER JOIN
      dbo.s_xz_mk1_view ON dbo.S_BDK_DBF.现状 = dbo.s_xz_mk1_view.xz_code ON 
      dbo.s_jfkm_mk1_view.jfkm_code = dbo.S_BDK_DBF.经费科目 LEFT OUTER JOIN
      dbo.s_sbly_mk1_view ON 
      dbo.S_BDK_DBF.设备来源 = dbo.s_sbly_mk1_view.sbly_code LEFT OUTER JOIN
      dbo.s_syfx_mk1_view ON 
      dbo.S_BDK_DBF.使用方向 = dbo.s_syfx_mk1_view.syfx_code
