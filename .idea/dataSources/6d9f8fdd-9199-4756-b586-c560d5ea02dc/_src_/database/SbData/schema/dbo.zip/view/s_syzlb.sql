CREATE VIEW dbo.s_syzlb
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 实验者类别名, 校编号, 
      校名称
FROM dbo.MK1
WHERE (BJ = '实验者类别')
