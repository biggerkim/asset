create procedure s_资产分类增减变动统计表_附件_gk @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类增减变动统计表_附件_gk_s_fj_dbf') and type='u')
exec('drop table '+@yh+'temp_分类增减变动统计表_附件_gk_s_fj_dbf')
else 
print '没有 '+@yh+'temp_分类增减变动统计表_附件_gk_s_fj_dbf'

exec('select * into '+@yh+'temp_分类增减变动统计表_附件_gk_s_fj_dbf from (
--在帐非转移和减少
--主机本期前入账，附件本期入账（本期增加的其他里该加）
select 分类号=left(b.分类号,2),现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_zjall a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
union all
--主机本期前入账，附件本期后入账（期末数该减）
select 分类号=left(b.分类号,2),现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_zjall a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 >'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
--主机本期入账，附件本期入账（购置该减附件，本期增加的其他里该加附件）
union all
select 分类号=left(b.分类号,2),现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_zjall a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
--主机本期入账，附件本期后入账（购置该减附件，期末数该减附件）
union all
select 分类号=left(b.分类号,2),现状=''gzqm'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_zjall a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
--减少
--主机本期前入账，附件本期入账，起始时间后减少（本期增加的其他里该加）
union all
select 分类号=left(b.分类号,2),现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_bdk_dbf a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and a.入库时间 < '''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期>='''+@qsrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
--主机本期前入账，附件本期后入账，主机本期后减少（期末数该减附件）
union all
select 分类号=left(b.分类号,2),现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_bdk_dbf a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and a.入库时间 < '''+@qsrq+''' and b.入库时间>'''+@jzrq+''' and a.变动日期>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)
--主机本期入账，附件本期入账，主机起始日期减少（购置减附件，本期增加的其他里该加附件）
union all
select 分类号=left(b.分类号,2),现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_bdk_dbf a,s_fj_dbf b where left(b.附件编号,8)=a.仪器编号 and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and a.入库时间 between  '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期>='''+@qsrq+''' and b.领用单位号 like '''+@lydw+'%'' group by left(b.分类号,2)

) b')

--**************************************************

