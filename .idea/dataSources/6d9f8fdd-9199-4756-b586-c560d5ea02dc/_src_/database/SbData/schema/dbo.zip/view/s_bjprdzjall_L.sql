CREATE VIEW dbo.s_bjprdzjall_L
AS
SELECT dbo.s_jfkm_mk1_view.校经费编号, dbo.s_jfkm_mk1_view.经费科目名, 
      dbo.s_sbly_mk1_view.设备来源名, dbo.s_sbly_mk1_view.校设源编号, 
      dbo.s_syfx_mk1_view.校使用编号, dbo.s_syfx_mk1_view.使用方向名, 
      dbo.s_xz_mk1_view.校现状编号, dbo.s_xz_mk1_view.现状名, 
      dbo.S_DW.校单位编号, dbo.S_DW.校单位名称, dbo.S_ZJALL.*
FROM dbo.s_jfkm_mk1_view INNER JOIN
      dbo.S_ZJALL ON 
      dbo.s_jfkm_mk1_view.jfkm_code = dbo.S_ZJALL.经费科目 INNER JOIN
      dbo.s_sbly_mk1_view ON 
      dbo.S_ZJALL.设备来源 = dbo.s_sbly_mk1_view.sbly_code INNER JOIN
      dbo.s_syfx_mk1_view ON 
      dbo.S_ZJALL.使用方向 = dbo.s_syfx_mk1_view.syfx_code INNER JOIN
      dbo.s_xz_mk1_view ON 
      dbo.S_ZJALL.现状 = dbo.s_xz_mk1_view.xz_code INNER JOIN
      dbo.S_DW ON dbo.S_ZJALL.领用单位号 = dbo.S_DW.单位编号
