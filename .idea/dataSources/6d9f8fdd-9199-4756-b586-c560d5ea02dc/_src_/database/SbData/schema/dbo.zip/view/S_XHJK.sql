CREATE VIEW dbo.S_XHJK
AS
SELECT dbo.S_ZC.领用单位号 AS 单位编号, dbo.S_DW.单位名称, 
      dbo.S_ZC.仪器编号 AS 资产编号, dbo.S_ZC.仪器名称 AS 资产名称, dbo.S_ZC.型号, 
      dbo.S_ZC.规格, dbo.S_ZC.金额, dbo.S_ZC.单价, dbo.S_ZC.厂家, dbo.S_ZC.出厂号, 
      dbo.S_ZC.出厂日期, dbo.S_ZC.购置日期, dbo.S_ZC.存放地名称, dbo.S_ZC.领用人, 
      dbo.S_ZC.经手人, dbo.S_ZC.输入人, dbo.S_ZC.记帐人, dbo.S_ZC.财务凭单, 
      dbo.S_ZC.输入日期, dbo.S_ZC.入库时间, dbo.S_ZC.变动日期, dbo.S_ZC.单据号, 
      dbo.S_ZC.备注, dbo.S_ZC.设备号 AS 资产号, dbo.S_ZC.科研号, dbo.S_ZC.折旧方式, 
      dbo.S_ZC.存放地编号, dbo.S_ZC.国标分类号, dbo.S_ZC.分类号, 
      dbo.S_ZC.使用单位号, dbo.S_ZC.附件总价, dbo.S_ZC.附件数量, dbo.S_ZC.保修期限, 
      dbo.S_ZC.国别, dbo.S_ZC.编号, dbo.S_ZC.国别码, dbo.S_ZC.数量, dbo.S_ZC.校区, 
      dbo.S_ZC.图片文件, dbo.S_ZC.图文名称, dbo.S_ZC.图片文件2, dbo.S_ZC.图文名称1, 
      dbo.S_ZC.图片文件1, dbo.S_ZC.图文名称2, dbo.S_ZC.图文名称3, 
      dbo.S_ZC.图片文件3, dbo.S_ZC.审核, dbo.S_ZC.管理级别, dbo.S_ZC.清查方式, 
      dbo.S_ZC.清查日期, dbo.S_ZC.清查异常, dbo.S_ZC.标志, dbo.S_ZC.财审核日期, 
      dbo.S_ZC.财务审核, dbo.S_ZC.财务审核人, dbo.S_ZC.初审, dbo.S_ZC.初审人, 
      dbo.S_ZC.初审日期, dbo.S_ZC.ID, dbo.S_ZC.人员编号, 
      dbo.S_SBLY.设备来源名 AS 设备来源, dbo.S_SYFX.使用方向名 AS 使用方向, 
      dbo.S_JFKM.经费科目名 AS 经费科目, dbo.S_XZ.现状名 AS 现状
FROM dbo.S_ZC INNER JOIN
      dbo.S_DW ON dbo.S_ZC.领用单位号 = dbo.S_DW.单位编号 INNER JOIN
      dbo.S_SBLY ON dbo.S_ZC.设备来源 = dbo.S_SBLY.code INNER JOIN
      dbo.S_SYFX ON dbo.S_ZC.使用方向 = dbo.S_SYFX.code INNER JOIN
      dbo.S_JFKM ON dbo.S_ZC.经费科目 = dbo.S_JFKM.code INNER JOIN
      dbo.S_XZ ON dbo.S_ZC.现状 = dbo.S_XZ.code
