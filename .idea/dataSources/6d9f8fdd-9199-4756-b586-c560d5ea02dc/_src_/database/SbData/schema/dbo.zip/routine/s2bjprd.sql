
CREATE PROCEDURE s2bjprd AS
DECLARE @ziduan nvarchar(2000)
DECLARE @ziduanzj nvarchar(2000)
declare   @sqlinsert   nvarchar(2000)  
declare   @sqlinsertzj   nvarchar(2000)  
begin 
set @ziduan =(SELECT *   FROM s_sbweb2bjprdbd);
set @ziduanzj =(SELECT *   FROM s_sbweb2bjprdzj);



delete from S_bdk_dbf_bjprd
print '变动库成功'

delete from S_ZJALL2Lbjprd
print '删除主机库成功'
select  @sqlinsert  = 'INSERT INTO S_bdk_dbf_bjprd (' + @ziduan +') SELECT '+@ziduan+' FROM s_bjprdbd_dbf_L'
select  @sqlinsertzj  = 'INSERT INTO S_ZJALL2Lbjprd (' + @ziduanzj +') SELECT '+@ziduanzj+' FROM s_bjprdzjall_L'
exec sp_executesql  @sqlinsert
print '成功添加变动库数据'
exec sp_executesql  @sqlinsertzj
print '成功添加主机库数据'
end
