CREATE VIEW dbo.s_czfs
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 40) AS 处置方式名, 
      校编号 AS 校处置方式, 校名称 AS 校处置方式名
FROM dbo.MK1
WHERE (BJ = '处置方式')
