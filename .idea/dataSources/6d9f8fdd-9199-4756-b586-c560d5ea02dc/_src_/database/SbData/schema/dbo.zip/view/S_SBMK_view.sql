
CREATE VIEW dbo.S_SBMK_view
AS
SELECT FLH, 使用年限, 残值百分比
FROM dbo.S_SBMK
GROUP BY FLH, 使用年限, 残值百分比

