CREATE VIEW dbo.s_cwsh
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 财务审核名
FROM dbo.MK1
WHERE (BJ = '财务审核')
