CREATE VIEW dbo.s_dwxz
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 单位性质名, 
      校编号 AS 校单位性质, 校名称 AS 校单位性质名
FROM dbo.MK1
WHERE (BJ = '单位性质')
