
CREATE VIEW dbo.S_BHFW_v
AS
SELECT dbo.S_ZJALL.领用单位号, dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, 
      dbo.S_ZJALL.规格, dbo.S_ZJALL.单价, dbo.S_ZJALL.购置日期, dbo.S_ZJALL.编号, 
      dbo.S_BHFW.最小编号, dbo.S_BHFW.最大编号, dbo.S_ZJALL.仪器编号
FROM dbo.S_ZJALL INNER JOIN
      dbo.S_BHFW ON dbo.S_ZJALL.领用单位号 = dbo.S_BHFW.领用单位号 AND 
      dbo.S_ZJALL.仪器名称 = dbo.S_BHFW.仪器名称 AND 
      dbo.S_ZJALL.型号 = dbo.S_BHFW.型号 AND 
      dbo.S_ZJALL.规格 = dbo.S_BHFW.规格 AND 
      dbo.S_ZJALL.单价 = dbo.S_BHFW.单价 AND 
      dbo.S_ZJALL.购置日期 = dbo.S_BHFW.购置日期

