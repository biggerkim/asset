
CREATE PROCEDURE setSystemVals 
@setTable varchar(200),
@setCol varchar(200),
@setVal varchar(20),
@setFlag varchar(1)
AS
DECLARE  @sbmkTable as varchar(200)
DECLARE  @kongx as varchar(200)
DECLARE  @rykTable as varchar(200)
--AUTHOR brightocean
--CREATETIME 2014-6-1
/*

111111111111111111111111111
清查方式------0"  为空——————————
数量-------1"  <=0
经费科目-------1"
折旧方式-------0"
采购形式-------3"
价值类型-------1"
记帐人-------*
领用人-------*
经手人-------*

使用方向-------1"
校区-------0"
审核-------0"
初审-------0"
财务审核-------0" ----------------
校区-------0
型号-------*
规格 -------*


22222222222222222222222222

厂家-------无 为空或者为 *


3333333333333333333333333
设备来源-------2"    经费科目是6  设备来源空
444444444444444444444
设备来源-------1"    经费科目<>6  设备来源空

5555555555555555555
出厂日期------- 购置日期     出厂日期》购置日期
使用单位号-------领用单位号
保修期限------- 购置日期
输入人-------记帐人

66666666666666666
国别码-------156   空或者S_gb中没有
国别-------中国


7777777777777777777777

六类资产=六大分类
国标分类号=czh
国标分类名=czm
计量单位=计量单位
资产类别=bzf
使用年限=使用年限
折旧残值=残值百分比*单价
字符字段7=mc


*/



if @setFlag='1'--第一类

begin
exec('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1')
--print('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1')
end

else if @setFlag='2'--第二类


begin
set @kongx='*'

exec('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1 or ltrim('+@setCol+')='''+@kongx+''' ')
--print('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1 or ltrim('+@setCol+')='''+@kongx+''' ')
end

else if @setFlag='3'--第3类针对经费科目值修改设备来源--默认2
begin
exec('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1 and Ltrim(经费科目)= 6 ')
end


else if @setFlag='4'--第3类针对经费科目值修改设备来源--默认1
begin
exec('update '+@setTable+' set '+@setCol+' ='''+@setVal+'''  where len('+@setCol+') <1 and Ltrim(经费科目)<> 6 ')
end

else if @setFlag='5'-- 
/*
使用单位号-------领用单位号
保修期限------- 购置日期
输入人-------记帐人

*/

begin
exec('update '+@setTable+' set 出厂日期 =购置日期  where  出厂日期> 购置日期')
exec('update '+@setTable+' set 使用单位号 =领用单位号  where  len(使用单位号)<1 ')
exec('update '+@setTable+' set 保修期限 =购置日期  where  保修期限< 购置日期 or len(保修期限)<1 ')

if @setTable<>'s_fj' and @setTable<>'s_fj_dbf'
begin
exec('update '+@setTable+' set 输入人 =记帐人  where len(输入人)<1 ')
end


end


else if @setFlag='6'-- 
begin


exec('update '+@setTable+' set 国别=''中国'',国别码=''156'' where len(国别)<1 or len(国别码)<1 or 国别码 not in(SELECT DM FROM s_gb) ')
end 

else if @setFlag='7'-- 
/*
六类资产=六大分类

国标分类号=czh

国标分类名=czm
资产类别=bzf
计量单位=计量单位
使用年限=使用年限
折旧残值=残值百分比*单价
字符字段7=mc

*/
begin

set @sbmkTable='s_sbmk'
exec('update '+@setTable+' set  '+@setTable+'.六类资产 = '+@sbmkTable+'.六大分类,'+@setTable+'.国标分类号 = '+@sbmkTable+'.czh,'+@setTable+'.国标分类名='+@sbmkTable+'.czm,'+@setTable+'.资产类别='+@sbmkTable+'.bzf,'+@setTable+'.计量单位='+@sbmkTable+'.计量单位,'+@setTable+'.使用年限='+@sbmkTable+'.使用年限,'+@setTable+'.字符字段7='+@sbmkTable+'.MC,'+@setTable+'.折旧残值 = '+@sbmkTable+'.残值百分比  *  '+@setTable+'.单价
 FROM '+@sbmkTable+' WHERE '+@sbmkTable+'.flh = '+@setTable+'.分类号 ')
end 


else
begin

set @rykTable='s_ryk'
exec('update '+@setTable+' set  '+@setTable+'.人员编号 = '+@rykTable+'.人员编号 FROM '+@rykTable+' WHERE len('+@setTable+'.人员编号)<1 and '+@rykTable+'.单位编号 = '+@setTable+'.领用单位号 and '+@rykTable+'.人员名 = '+@setTable+'.领用人 ')
print('update '+@setTable+' set  '+@setTable+'.人员编号 = '+@rykTable+'.人员编号 FROM '+@rykTable+' WHERE len('+@setTable+'.人员编号)<1 and '+@rykTable+'.单位编号 = '+@setTable+'.领用单位号 and '+@rykTable+'.人员名 = '+@setTable+'.领用人 ')
end

--print ('update '+@setTable+' set  '+@setTable+'.六类资产 = '+@sbmkTable+'.六大分类,'+@setTable+'.国标分类号 = '+@sbmkTable+'.czh,'+@setTable+'.国标分类名='+@sbmkTable+'.czm,'+@setTable+'.资产类别='+@sbmkTable+'.bzf,'+@setTable+'.计量单位='+@sbmkTable+'.计量单位,'+@setTable+'.使用年限='+@sbmkTable+'.使用年限,'+@setTable+'.字符字段7='+@sbmkTable+'.MC,'+@setTable+'.折旧残值 = '+@sbmkTable+'.残值百分比  *  '+@setTable+'.单价
-- FROM '+@sbmkTable+' WHERE '+@sbmkTable+'.flh = S_ZJALL.分类号 ')




