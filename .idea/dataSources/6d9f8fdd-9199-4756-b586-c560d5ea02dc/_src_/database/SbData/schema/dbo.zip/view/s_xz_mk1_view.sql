
CREATE VIEW dbo.s_xz_mk1_view
AS
SELECT BJ, 校编号 AS 校现状编号, 校名称 AS 现状名, LEFT(NR, 1) AS xz_code
FROM dbo.MK1
WHERE (BJ = '现状')

