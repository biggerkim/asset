





CREATE procedure s_分类查询_折旧十一类 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50),@keyan varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end
--删除临时表

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类查询_折旧十一类') and type='u')
exec('drop table '+@yh+'temp_分类查询_折旧十一类')
else 
print '没有 '+@yh+'temp_分类查询_折旧十一类'

if exists(select 1 from sysobjects where name = 'temp_分类查询_折旧十一类') 
drop table temp_分类查询_折旧十一类
else 
print '没有 temp_分类查询_折旧十一类'


--目前在帐设备
--(非年末数)
exec('select 分类号=left(资产类别,2),总数量=count(*),总价=sum(单价),月折旧额=sum(月折旧额),累计折旧额=sum(累计折旧额) into '+@yh+'temp_分类查询_折旧十一类 from S_ZJ_zhejiu_view where '+@keyan+' and 入库时间<='''+@jzrq+''' and (仪器编号 NOT IN (SELECT 仪器编号 FROM S_bdk_dbf WHERE 现状 = ''6'' and 变动日期<'''+@qsrq+''')) and 领用单位号 like '''+@lydw+'%'' group by left(资产类别,2) order by left(资产类别,2)')



