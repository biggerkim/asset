CREATE VIEW dbo.S_JFKM
AS
SELECT TOP 100 PERCENT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) 
      AS 经费科目名, 校编号 AS 校经费科目, 校名称 AS 校经费科目名
FROM dbo.MK1
WHERE (BJ = '经费科目')
ORDER BY LEFT(NR, 1)
