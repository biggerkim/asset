


create procedure s_国有资产基本情况表 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50),@condition varchar(100)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_国有资产基本情况表_s_zjall') and type='u')
exec('drop table '+@yh+'temp_国有资产基本情况表_s_zjall')
else 
print '没有 '+@yh+'temp_国有资产基本情况表_s_zjall'
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_国有资产基本情况表_s_zjall_dwxz') and type='u')
begin
exec('drop table '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz')
end
if exists(select 1 from sysobjects where name = 'temp_国有资产基本情况表_s_zjall') 
drop table temp_国有资产基本情况表_s_zjall
else 
print '没有 temp_国有资产基本情况表_s_zjall'
if exists(select 1 from sysobjects where name = 'temp_国有资产基本情况表_s_zjall_dwxz') 
begin
drop table temp_国有资产基本情况表_s_zjall_dwxz
end
--***************
--测试用例
--declare @qsrq varchar(30),@jzrq varchar(30),@lydw varchar(10),@yh varchar(50)
--set @qsrq='1900-01-01'
--set @jzrq='2010-12-31'
--set @lydw=''
--set @yh='管理员'
--exec('drop table '+@yh+'temp_国有资产基本情况表_s_zjall')
--**************

exec('select * into '+@yh+'temp_国有资产基本情况表_s_zjall from (
--目前在帐设备
--(年末数)
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,使用方向=使用方向,单位标志=''*'' from s_zjall where 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
union all
--本期在帐数(非年末数，本期增加)
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,使用方向=使用方向,单位标志=''*'' from s_zjall where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价,使用方向 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
union all
--（非内部调拨、增减值）本期增加数

select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zj'',总数量=count(*),总价=sum(单价),单价=单价,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
union all
--（非内部调拨、增减值）本期减少数

select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价,使用方向
union all
--目前变动库里的增减值资产
--（年末数）
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=0,总价=-sum(变动单价),单价=0,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where  入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
union all
--（非年末数）本期增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zz'',总数量=0,总价=sum(变动单价),单价=0,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
--（非年末数）本期减值数
union all
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''jz'',总数量=0,总价=-sum(变动单价),单价=0,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向
union all
--本期增加数里减值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bj'',总数量=0,总价=-sum(变动单价),单价=0,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向

union all
--本期增加数里增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bz'',总数量=0,总价=sum(变动单价),单价=0,使用方向=使用方向,单位标志=''*'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价,使用方向

) b')
--**************
--生成单位性质数据
exec('select * into '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz from (
--目前在帐设备
--(年末数)
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''@'',总数量=count(*),总价=sum(单价) from s_zjall,s_dw where s_zjall.领用单位号=s_dw.单位编号 and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by 单位性质
union all
--本期在帐数(非年末数，本期增加)
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状,总数量=count(*),总价=sum(单价) from s_zjall,s_dw where s_zjall.领用单位号=s_dw.单位编号 and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by 单位性质,现状 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''@'',总数量=count(*),总价=sum(单价) from s_bdk_dbf,s_dw where s_bdk_dbf.领用单位号=s_dw.单位编号 and 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by 单位性质
union all
--（非内部调拨、增减值）本期增加数

select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''zj'',总数量=count(*),总价=sum(单价) from s_bdk_dbf,s_dw where s_bdk_dbf.领用单位号=s_dw.单位编号 and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by 单位性质
union all
--（非内部调拨、增减值）本期减少数

select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状,总数量=count(*),总价=sum(单价) from s_bdk_dbf,s_dw where s_bdk_dbf.领用单位号=s_dw.单位编号 and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by 单位性质,现状
union all
--目前变动库里的增减值资产
--（年末数）
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''@'',总数量=0,总价=-sum(变动单价) from s_bdk_dbf,s_dw where  s_bdk_dbf.领用单位号=s_dw.单位编号 and 入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 and '+@condition+' group by 单位性质
union all
--（非年末数）本期增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''zz'',总数量=0,总价=sum(变动单价) from s_bdk_dbf,s_dw where  s_bdk_dbf.领用单位号=s_dw.单位编号 and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by 单位性质
--（非年末数）本期减值数
union all
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''jz'',总数量=0,总价=-sum(变动单价) from s_bdk_dbf,s_dw where  s_bdk_dbf.领用单位号=s_dw.单位编号 and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 and '+@condition+' group by 单位性质
union all
--本期增加数里减值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''bj'',总数量=0,总价=-sum(变动单价) from s_bdk_dbf,s_dw where  s_bdk_dbf.领用单位号=s_dw.单位编号 and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 and '+@condition+' group by 单位性质

union all
--本期增加数里增值数
select 序列1=''aa'',序列2=''aa'',序列3=''aaaaaa'',单位性质,现状=''bz'',总数量=0,总价=sum(变动单价) from s_bdk_dbf,s_dw where s_bdk_dbf.领用单位号=s_dw.单位编号 and  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by 单位性质

) c')
--报表输出条件
--行政 序列3=0301
--事业 序列3=0302
--社团 序列3=0303
--其他 序列3=0304
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz set 序列3=''0301'' where (单位性质=''3'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz set 序列3=''0302'' where (单位性质=''1'' or 单位性质=''2'' or 单位性质=''4'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz set 序列3=''0302'' where (单位性质=''5'' or 单位性质=''6'' or 单位性质=''7'')')

--*******************************************************************
--报表输出条件
--土地、房屋及构筑物  序列1=10 
--办公用房业务用房  序列2=11
--土地 序列2=12
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''10'' where (国标分类号=''02'' or 国标分类号=''03'' or 国标分类号=''01'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列2=''11'' where 序列1=''10'' and (left(国标分类号0,3)=''022'' or left(国标分类号0,3)=''024'' or left(国标分类号0,3)=''025'' or left(国标分类号0,3)=''026'' or left(国标分类号0,3)=''028'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列2=''12'' where 序列1=''10'' and 国标分类号=''01''')
--一般设备 序列1=20
--载客汽车和轿车 序列2=21
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''20'' where ((国标分类号 between ''06'' and ''21'') or (国标分类号 between ''52'' and ''56'') or (国标分类号 between ''60'' and ''65'') or (国标分类号 between ''68'' and ''71'') or (国标分类号 between ''74'' and ''77'') or (国标分类号 between ''80'' and ''82'') or (国标分类号 between ''90'' and ''92''))')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列2=''21'' where 序列1=''20'' and (left(国标分类号0,4)=''5316'' or left(国标分类号0,4)=''5315'')')
--专用设备 序列1=30
--单价100万以上设备 序列2=31
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''30'' where (国标分类号 between ''25'' and ''47'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列2=''31'' where 序列1=''30'' and 单价>1000000')
--文物及陈列品 序列1=40
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''40'' where (国标分类号 between ''86'' and ''87'')')
--图书 序列1=50
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''50'' where (国标分类号 = ''85'')')
--其他资产 序列1=60
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列1=''60'' where (序列1=''aa'')')
--************************************形成用途分类
--非经营性资产  序列3=0201
--其中：由下属企事业单位占用  序列3=020101
--经营性资产   序列3=0202
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列3=''0201'' where (使用方向=''1'' or 使用方向=''2'' or 使用方向=''3'' or 使用方向=''4'' or 使用方向=''5'' or 使用方向=''6'' or 使用方向=''7'' or 使用方向=''9'' or 使用方向=''A'')')
exec('update '+@yh+'temp_国有资产基本情况表_s_zjall set 序列3=''0202'' where (使用方向=''B'' or 使用方向=''C'' or 使用方向=''D'' or 使用方向=''E'')')


--***********************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'国有资产基本情况表') and type='u')
begin
exec('drop table '+@yh+'国有资产基本情况表')
end

if exists(select 1 from sysobjects where name = '国有资产基本情况表') 
begin
drop table 国有资产基本情况表
end
create table 国有资产基本情况表(xh int,m1 varchar(40),m2 varchar(8),hc varchar(2),sl_1 int default 0,je_1 numeric(14,2)  default 0.00,sl_2 int default 0,je_2 numeric(14,2) default 0,sl_3 int default 0,je_3 numeric(14,2) default 0,sl_4 int default 0,je_4 numeric(14,2) default 0,sl_5 int default 0,je_5 numeric(14,2) default 0,sl_6 int default 0,je_6 numeric(14,2) default 0,sl_7 int default 0,je_7 numeric(14,2) default 0,sl_8 int default 0,je_8 numeric(14,2) default 0,sl_9 int default 0,je_9 numeric(14,2) default 0,sl_A int default 0,je_A numeric(14,2) default 0,sl_B int default 0,je_B numeric(14,2) default 0,sl_C int default 0,je_C numeric(14,2) default 0,sl_D int default 0,je_D numeric(14,2) default 0,sl_E int default 0,je_E numeric(14,2) default 0,sl_F int default 0,je_F numeric(14,2) default 0,sl_G int default 0,je_G numeric(14,2) default 0,sl_H int default 0,je_H numeric(14,2) default 0,sl_I int default 0,je_I numeric(14,2) default 0,sl_J int default 0,je_J numeric(14,2) default 0,sl_P int default 0,je_P numeric(14,2) default 0,
sl_Q int default 0,je_Q numeric(14,2) default 0,sl_R int default 0,je_R numeric(14,2) default 0,sl_S int default 0,je_S numeric(14,2) default 0,sl_T int default 0,je_T numeric(14,2) default 0,sl_U int default 0,je_U numeric(14,2) default 0,sl_V int default 0,je_V numeric(14,2) default 0,sl_W int default 0,je_W numeric(14,2) default 0,sl_X int default 0,je_X numeric(14,2) default 0,
sl_@ int default 0,je_@ numeric(14,2) default 0,sl_zj int default 0,je_zj numeric(14,2) default 0,
sl_zz int default 0,je_zz numeric(14,2) default 0,sl_jz int default 0,je_jz numeric(14,2) default 0,
sl_bj int default 0,je_bj numeric(14,2) default 0,sl_bz int default 0,je_bz numeric(14,2) default 0
)
insert into 国有资产基本情况表(xh,m1,m2,hc) values(1,'资产总计','00','1')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(2,'一、按存在形式分类','01','2')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(3,'(一)流动资产','0101','3')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(4,'(二)固定资产','0102','4')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(5,'1.房屋、土地和构筑物','10','5')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(6,'其中：办公与业务用房','11','6')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(7,'其中：土地','12','7')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(8,'2.专用设备','30','8')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(9,'其中：价值100万元以上设备','31','9')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(10,'3.一般设备','20','10')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(11,'其中：载客汽车和轿车','21','11')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(12,'4.文物及陈列品','40','12')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(13,'5.图书','50','13')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(14,'6.其它资产','60','14')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(15,'(三)对外投资','0103','15')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(16,'(四)无形资产','0104','16')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(17,'(五)其它资产','0105','17')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(18,'二、按用途分类','02','18')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(19,'(一)非经营性资产','0201','19')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(20,'其中：由下属企业单位占用','020101','20')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(21,'(二)经营性资产','0202','21')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(22,'三、按单位性质分类','03','22')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(23,'(一)行政','0301','23')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(24,'(二)事业','0302','24')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(25,'(三)社团','0303','25')
insert into 国有资产基本情况表(xh,m1,m2,hc) values(26,'(四)社团','0304','26')
--********************************处理单位性质数据


if exists(select 1 from sysobjects where name = 'temp_国有资产基本情况表_dwxz') 
begin
drop table temp_国有资产基本情况表_dwxz
end
exec('select 序列1,序列2,序列3,现状,总价=sum(总价),总数量=sum(总数量) into temp_国有资产基本情况表_dwxz from '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz group by 序列1,序列2,序列3,现状')
declare @xl1 varchar(8), @xl2 varchar(8),@xl3 varchar(8),@zj numeric(14,2),@zsl int,@xz varchar(4)

while (select count(*) from temp_国有资产基本情况表_dwxz)>0
begin
select top 1 @xl1=序列1, @xl2=序列2,@xl3=序列3,@xz=现状,@zj=总价,@zsl=总数量 from temp_国有资产基本情况表_dwxz
if @xz='1'
begin
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl3
end
else if @xz='2'
begin
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl3

end
else if @xz='3'
begin
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl3

end
else if @xz='4'
begin
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl3

end
else if @xz='5'
begin
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl3

end
else if @xz='6'
begin
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl3

end
else if @xz='7'
begin
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl3
end
else if @xz='8'
begin
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl3

end
else if @xz='9'
begin
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl3

end
else if @xz='A'
begin
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl3
end
else if @xz='B'
begin
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl3

end
else if @xz='C'
begin
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl3
end
else if @xz='D'
begin
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl3

end
else if @xz='E'
begin
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl3

end
else if @xz='F'
begin
update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2=@xl3

end
else if @xz='G'
begin
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl3

end
else if @xz='H'
begin
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl3
end
else if @xz='I'
begin
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl3

end
else if @xz='J'
begin
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl3
end
else if @xz='P'
begin
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl3

end
else if @xz='Q'
begin
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl3

end
else if @xz='R'
begin
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl3

end
else if @xz='S'
begin
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl3

end
else if @xz='T'
begin
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl3

end
else if @xz='U'
begin
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl3

end
else if @xz='V'
begin
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl3

end
else if @xz='W'
begin
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl3

end
else if @xz='X'
begin
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl3

end
else if @xz='@'
begin
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl3

end
else if @xz='zj'
begin
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl3

end
else if @xz='zz'
begin
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl3

end
else if @xz='jz'
begin
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl3

end
else if @xz='bj'
begin
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl3
end
else if @xz='bz'
begin
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl3

end
else
print '现状有异常'

delete from temp_国有资产基本情况表_dwxz where 序列2=@xl2 and 序列1=@xl1 and 现状=@xz and 总价=@zj and 总数量=@zsl and 序列3=@xl3
end
drop table temp_国有资产基本情况表_dwxz
--************************************************

if exists(select 1 from sysobjects where name = 'temp_国有资产基本情况表') 
begin
drop table temp_国有资产基本情况表
end
exec('select 序列1,序列2,序列3,现状,总价=sum(总价),总数量=sum(总数量) into temp_国有资产基本情况表 from '+@yh+'temp_国有资产基本情况表_s_zjall group by 序列1,序列2,序列3,现状')
--declare @xl1 varchar(8), @xl2 varchar(8),@xl3 varchar(8),@zj numeric(14,2),@zsl int,@xz varchar(4)

while (select count(*) from temp_国有资产基本情况表)>0
begin
select top 1 @xl1=序列1, @xl2=序列2,@xl3=序列3,@xz=现状,@zj=总价,@zsl=总数量 from temp_国有资产基本情况表
if @xz='1'
begin
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl2
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2='00'
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2='0102'
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl1
update 国有资产基本情况表 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl3

end
else if @xz='2'
begin
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl2
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2='00'
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2='0102'
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl1
update 国有资产基本情况表 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl3

end
else if @xz='3'
begin
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl2
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2='00'
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2='0102'
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl1
update 国有资产基本情况表 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl3

end
else if @xz='4'
begin
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl2
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2='00'
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2='0102'
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl1
update 国有资产基本情况表 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl3


end
else if @xz='5'
begin
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl2
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2='00'
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2='0102'
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl1
update 国有资产基本情况表 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl3

end
else if @xz='6'
begin
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl2
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2='00'
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2='0102'
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl1
update 国有资产基本情况表 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl3

end
else if @xz='7'
begin
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl2
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2='00'
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2='0102'
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl1
update 国有资产基本情况表 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl3

end
else if @xz='8'
begin
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl2
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2='00'
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2='0102'
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl1
update 国有资产基本情况表 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl3

end
else if @xz='9'
begin
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl2
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2='00'
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2='0102'
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl1
update 国有资产基本情况表 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl3

end
else if @xz='A'
begin
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl2
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2='00'
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2='0102'
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl1
update 国有资产基本情况表 set sl_A=sl_A+@zsl,je_A=je_A+@zj where m2=@xl3

end
else if @xz='B'
begin
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl2
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2='00'
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2='0102'
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl1
update 国有资产基本情况表 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl3

end
else if @xz='C'
begin
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl2
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2='00'
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2='0102'
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl1
update 国有资产基本情况表 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl3

end
else if @xz='D'
begin
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl2
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2='00'
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2='0102'
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl1
update 国有资产基本情况表 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl3

end
else if @xz='E'
begin
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl2
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2='00'
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2='0102'
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl1
update 国有资产基本情况表 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl3

end
else if @xz='F'
begin
update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2=@xl2
update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2='00'
update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2='0102'
update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2=@xl1

update 国有资产基本情况表 set sl_F=sl_F+@zsl,je_F=je_F+@zj where m2=@xl3

end
else if @xz='G'
begin
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl2
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2='00'
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2='0102'
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl1
update 国有资产基本情况表 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl3

end
else if @xz='H'
begin
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl2
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2='00'
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2='0102'
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl1
update 国有资产基本情况表 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl3

end
else if @xz='I'
begin
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl2
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2='00'
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2='0102'
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl1
update 国有资产基本情况表 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl3

end
else if @xz='J'
begin
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl2
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2='00'
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2='0102'
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl1
update 国有资产基本情况表 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl3

end
else if @xz='P'
begin
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl2
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2='00'
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2='0102'
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl1
update 国有资产基本情况表 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl3

end
else if @xz='Q'
begin
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl2
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2='00'
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2='0102'
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl1
update 国有资产基本情况表 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl3

end
else if @xz='R'
begin
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl2
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2='00'
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2='0102'
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl1
update 国有资产基本情况表 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl3

end
else if @xz='S'
begin
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl2
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2='00'
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2='0102'
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl1
update 国有资产基本情况表 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl3

end
else if @xz='T'
begin
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl2
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2='00'
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2='0102'
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl1
update 国有资产基本情况表 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl3

end
else if @xz='U'
begin
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl2
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2='00'
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2='0102'
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl1
update 国有资产基本情况表 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl3

end
else if @xz='V'
begin
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl2
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2='00'
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2='0102'
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl1
update 国有资产基本情况表 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl3
end
else if @xz='W'
begin
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl2
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2='00'
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2='0102'
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl1
update 国有资产基本情况表 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl3

end
else if @xz='X'
begin
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl2
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2='00'
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2='0102'
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl1
update 国有资产基本情况表 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl3

end
else if @xz='@'
begin
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl2
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2='00'
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2='0102'
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl1
update 国有资产基本情况表 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl3

end
else if @xz='zj'
begin
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl2
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2='00'
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2='0102'
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl1
update 国有资产基本情况表 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl3

end
else if @xz='zz'
begin
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl2
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2='00'
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2='0102'
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl1
update 国有资产基本情况表 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl3

end
else if @xz='jz'
begin
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl2
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2='00'
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2='0102'
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl1
update 国有资产基本情况表 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl3

end
else if @xz='bj'
begin
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl2
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2='00'
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2='0102'
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl1
update 国有资产基本情况表 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl3

end
else if @xz='bz'
begin
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl2
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2='00'
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2='0102'
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl1
update 国有资产基本情况表 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl3

end
else
print '现状有异常'

delete from temp_国有资产基本情况表 where 序列2=@xl2 and 序列1=@xl1 and 现状=@xz and 总价=@zj and 总数量=@zsl and 序列3=@xl3
end
drop table temp_国有资产基本情况表
exec('drop table '+@yh+'temp_国有资产基本情况表_s_zjall')
exec('drop table '+@yh+'temp_国有资产基本情况表_s_zjall_dwxz')



