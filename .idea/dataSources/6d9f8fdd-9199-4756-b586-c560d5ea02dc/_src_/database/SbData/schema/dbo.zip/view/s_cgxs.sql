
CREATE VIEW dbo.s_cgxs
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 采购形式名, 
      校编号 AS 校采购形式, 校名称 AS 校采购形式名
FROM dbo.MK1
WHERE (BJ = '采购形式')

