
CREATE VIEW dbo.w_cl_view
AS
SELECT dbo.w_wxcl.*, SUBSTRING(维修Id, 2, 20) AS 单据号
FROM dbo.w_wxcl

