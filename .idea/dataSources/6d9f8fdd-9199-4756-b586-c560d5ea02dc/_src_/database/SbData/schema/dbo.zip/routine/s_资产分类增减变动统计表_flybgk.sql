create procedure s_资产分类增减变动统计表_flybgk @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分类增减变动统计表_flybgk_s_zjall') and type='u')
exec('drop table '+@yh+'temp_分类增减变动统计表_flybgk_s_zjall')
else 
print '没有 '+@yh+'temp_分类增减变动统计表_flybgk_s_zjall'


--***************
--测试用例
--declare @qsrq varchar(30),@jzrq varchar(30),@lydw varchar(10),@yh varchar(50)
--set @qsrq='1900-01-01'
--set @jzrq='2010-12-31'
--set @lydw=''
--set @yh='管理员'
--exec('drop table '+@yh+'temp_分类增减变动统计表_flybgk_s_zjall')
--**************
exec('select * into '+@yh+'temp_分类增减变动统计表_flybgk_s_zjall from (
--目前在帐资产
--(年末数)
select 分类号=left(分类号,2),现状=''@'',使用方向,总数量=count(*),总价=sum(单价),单位标志=''*'',类别=''shb'' from s_zjall where 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(分类号,2),使用方向
union all
--本期在帐数(非年末数，本期增加)
select 分类号=left(分类号,2),现状,使用方向,总数量=count(*),总价=sum(单价),单位标志=''*'',类别=''shb'' from s_zjall where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by left(分类号,2),现状,使用方向 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 分类号=left(分类号,2),现状=''@'',使用方向,总数量=count(*),总价=sum(单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') group by left(分类号,2),使用方向
union all
--（非内部调拨、增减值）本期增加数

select 分类号=left(分类号,2),现状=''zj'',使用方向,总数量=count(*),总价=sum(单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') group by left(分类号,2),使用方向
union all
--（非内部调拨、增减值）本期减少数

select 分类号=left(分类号,2),现状,使用方向,总数量=count(*),总价=sum(单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') group by left(分类号,2),现状,使用方向
union all
--目前变动库里的增减值资产
--（年末数）
select 分类号=left(分类号,2),现状=''@'',使用方向,总数量=0,总价=-sum(变动单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where  入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 group by left(分类号,2),使用方向
union all
--（非年末数）本期增值数
select 分类号=left(分类号,2),现状=''zz'',使用方向,总数量=0,总价=sum(变动单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 group by left(分类号,2),使用方向
--（非年末数）本期减值数
union all
select 分类号=left(分类号,2),现状=''jz'',使用方向,总数量=0,总价=-sum(变动单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 group by left(分类号,2),使用方向
union all
--本期增加数里减值数
select 分类号=left(分类号,2),现状=''bj'',使用方向,总数量=0,总价=-sum(变动单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 group by left(分类号,2),使用方向

union all
--本期增加数里增值数
select 分类号=left(分类号,2),现状=''bz'',使用方向,总数量=0,总价=sum(变动单价),单位标志=''*'',类别=''shb'' from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 group by left(分类号,2),使用方向

) b')
--**************************************************

