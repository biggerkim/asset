
CREATE VIEW dbo.S_WCZJ_view
AS
SELECT 领用单位号, 仪器编号, 仪器名称, 型号, 规格, 单价, 购置日期, 入库时间, 
      残值百分比, 应使用月份, 已使用月份, CAST(月折旧额 AS decimal(18, 2)) AS 月折旧额, 
      CAST(累计折旧额 AS decimal(18, 2)) AS 累计折旧额, CAST(净值 AS decimal(18, 2)) 
      AS 净值, CAST(残值 AS decimal(18, 2)) AS 残值, 现状, 分类号, 变动日期, 
      折旧方式
FROM dbo.S_ZJ_zhejiu_view
WHERE (已使用月份 > 应使用月份) OR
      (已使用月份 = 0)

