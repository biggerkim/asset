





CREATE procedure zc_购置折旧信息 @endtime smalldatetime
as
exec('UPDATE S_ZheJiu_view SET 残值百分比 = 残值百分比1, 月折旧额 = CAST(月折旧额1 AS decimal(18, 2)), 应使用月份 = 使用年限1 * 12,残值 = 单价*残值百分比1, 已使用月份 = (YEAR('''+@endtime+''') -YEAR(购置日期))* 12 + MONTH('''+@endtime+''') - MONTH(购置日期)')
exec('UPDATE S_ZJ_zhejiu_view SET 净值 = CAST(单价 - 月折旧额 * 已使用月份 AS decimal(18, 2)),累计折旧额 = CAST(月折旧额 * 已使用月份 AS decimal(18, 2)) WHERE (已使用月份 <= 应使用月份)')
exec('UPDATE S_ZJ_zhejiu_view SET 净值 = 残值,累计折旧额 = CAST((单价-残值) AS decimal(18, 2)),月折旧额=0 WHERE (已使用月份 > 应使用月份)')
exec('UPDATE S_ZJ_zhejiu_view SET 月折旧额=0 WHERE (已使用月份 = 0)')
exec('UPDATE S_ZJ_zhejiu_view SET 净值 = 单价,累计折旧额 = 0,月折旧额=0 WHERE (折旧方式 <> ''1'')')



