CREATE VIEW dbo.s_tjbz
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 调剂标志名
FROM dbo.MK1
WHERE (BJ = '调剂标志')
