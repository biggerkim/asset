CREATE VIEW dbo.s_zfzd7
AS
SELECT dbo.S_SBMK.FLH, dbo.S_ZJALL.分类号, dbo.S_ZJALL.字符字段7, 
      dbo.S_SBMK.MC
FROM dbo.S_ZJALL INNER JOIN
      dbo.S_SBMK ON dbo.S_ZJALL.分类号 = dbo.S_SBMK.FLH
