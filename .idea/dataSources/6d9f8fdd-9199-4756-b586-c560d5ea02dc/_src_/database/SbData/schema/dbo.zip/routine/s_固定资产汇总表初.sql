
CREATE procedure s_固定资产汇总表初 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_固定资产汇总表初_s_zjall') and type='u')
exec('drop table '+@yh+'temp_固定资产汇总表初_s_zjall')
else 
print '没有 '+@yh+'temp_固定资产汇总表初_s_zjall'

if exists(select 1 from sysobjects where name = 'temp_固定资产汇总表初_s_zjall') 
drop table temp_固定资产汇总表初_s_zjall
else 
print '没有 temp_固定资产汇总表初_s_zjall'
exec('select * into '+@yh+'temp_固定资产汇总表初_s_zjall from (
--目前在帐设备
--本期在帐数(非年末数，本期增加)
SELECT zj.分类号 AS 分类号, zj.现状, zj.单价 AS 总价,zj.入库时间, zj.经费科目, zj.仪器编号 AS 仪器编号, zj.单据号 FROM S_ZJALL zj WHERE (zj.入库时间 >= '''+@qsrq+''') AND (zj.入库时间 <= '''+@jzrq+''')
union all
--本期增加数里增值数
select 分类号=''附件'',现状,总价=sum(附件单价),入库时间,经费科目,仪器编号=附件编号,单据号 from S_FJ_DBF where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by 现状 ,入库时间,经费科目,附件编号,单据号
) b')
