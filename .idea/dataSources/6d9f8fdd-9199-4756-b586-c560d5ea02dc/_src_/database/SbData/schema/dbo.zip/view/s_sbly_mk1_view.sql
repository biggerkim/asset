
CREATE VIEW dbo.s_sbly_mk1_view
AS
SELECT BJ, 校名称 AS 设备来源名, 校编号 AS 校设源编号, LEFT(NR, 1) 
      AS sbly_code
FROM dbo.MK1
WHERE (BJ = '设备来源')

