CREATE VIEW dbo.s_jfkm_mk1_view
AS
SELECT BJ, 校编号 AS 校经费编号, 校名称 AS 经费科目名, LEFT(NR, 1) 
      AS jfkm_code
FROM dbo.MK1
WHERE (BJ = '经费科目')
