CREATE procedure zc_删除用户统计表
as
declare @table varchar(50)
set @table=''
if exists(select 1 from sysobjects where name = 'tables') 
drop table tables
else
print '开始清除用户统计表'
select 用户名 into tables from emp_code
update tables set 用户名 = 'PRD' + 用户名
while (select count(*) from tables)>0
begin
select top 1 @table=rtrim(用户名) from tables order by 用户名
print '被清除报表的用户是：'+@table
--*********************
--删除表区
if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类增减变动统计表_s_zjall') and type='u')
exec('drop table '+@table+'temp_分类增减变动统计表_s_zjall')
else 
print '已经没有 '+@table+'temp_分类增减变动统计表_s_zjall'
if exists(select 1 from sysobjects where id = object_id('temp_分类增减变动统计表_s_zjall') and type='u')
exec('drop table temp_分类增减变动统计表_s_zjall')
else 
print '已经没有 temp_分类增减变动统计表_s_zjall'
--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备折旧分户查询统计表_last') and type='u')
exec('drop table '+@table+'temp_设备折旧分户查询统计表_last')
else 
print '已经没有 '+@table+'temp_设备折旧分户查询统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备折旧分户查询统计表_last') and type='u')
exec('drop table temp_设备折旧分户查询统计表_last')
else 
print '已经没有 temp_设备折旧分户查询统计表_last'


--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_折旧十一类') and type='u')
exec('drop table '+@table+'temp_分类查询_折旧十一类')
else 
print '已经没有 '+@table+'temp_分类查询_折旧十一类'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_折旧十一类') and type='u')
exec('drop table temp_分类查询_折旧十一类')
else 
print '已经没有 temp_分类查询_折旧十一类'


--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_折旧十六类') and type='u')
exec('drop table '+@table+'temp_分类查询_折旧十六类')
else 
print '已经没有 '+@table+'temp_分类查询_折旧十六类'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_折旧十六类') and type='u')
exec('drop table temp_分类查询_折旧十六类')
else 
print '已经没有 temp_分类查询_折旧十六类'


--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_折旧六类') and type='u')
exec('drop table '+@table+'temp_分类查询_折旧六类')
else 
print '已经没有 '+@table+'temp_分类查询_折旧六类'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_折旧六类') and type='u')
exec('drop table temp_分类查询_折旧六类')
else 
print '已经没有 temp_分类查询_折旧六类'

--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_固定资产汇总表初_s_zjall') and type='u')
exec('drop table '+@table+'temp_固定资产汇总表初_s_zjall')
else 
print '已经没有 '+@table+'temp_固定资产汇总表初_s_zjall'
if exists(select 1 from sysobjects where id = object_id('temp_固定资产汇总表初_s_zjall') and type='u')
exec('drop table temp_固定资产汇总表初_s_zjall')
else 
print '已经没有 temp_固定资产汇总表初_s_zjall'
--*******************************************************************************************************************************************************
if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_在帐本期增加数') and type='u')
exec('drop table '+@table+'temp_分类查询_在帐本期增加数')
else 
print '已经没有 '+@table+'temp_分类查询_在帐本期增加数'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_在帐本期增加数') and type='u')
exec('drop table temp_分类查询_在帐本期增加数')
else 
print '已经没有 temp_分类查询_在帐本期增加数'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_变动本期增加数') and type='u')
exec('drop table '+@table+'temp_分类查询_变动本期增加数')
else 
print '已经没有 '+@table+'temp_分类查询_变动本期增加数'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_变动本期增加数') and type='u')
exec('drop table temp_分类查询_变动本期增加数')
else 
print '已经没有 temp_分类查询_变动本期增加数'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_本期后增减值数') and type='u')
exec('drop table '+@table+'temp_分类查询_本期后增减值数')
else 
print '已经没有 '+@table+'temp_分类查询_本期后增减值数'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_本期后增减值数') and type='u')
exec('drop table temp_分类查询_本期后增减值数')
else 
print '已经没有 temp_分类查询_本期后增减值数'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备分户查询统计表_last') and type='u')
exec('drop table '+@table+'temp_设备分户查询统计表_last')
else 
print '已经没有 '+@table+'temp_设备分户查询统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备分户查询统计表_last') and type='u')
exec('drop table temp_设备分户查询统计表_last')
else 
print '已经没有 temp_设备分户查询统计表_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备分户增减变动统计表_last') and type='u')
exec('drop table '+@table+'temp_设备分户增减变动统计表_last')
else 
print '已经没有 '+@table+'temp_设备分户增减变动统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备分户增减变动统计表_last') and type='u')
exec('drop table temp_设备分户增减变动统计表_last')
else 
print '已经没有 temp_设备分户增减变动统计表_last' 
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'分类查询统计表_11_last') and type='u')
exec('drop table '+@table+'分类查询统计表_11_last')
else 
print '已经没有 '+@table+'分类查询统计表_11_last'
if exists(select 1 from sysobjects where id = object_id('分类查询统计表_11_last') and type='u')
exec('drop table 分类查询统计表_11_last')
else 
print '已经没有 分类查询统计表_11_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('drop table '+@table+'temp_设备分户增减变动统计表_附件_last')
else 
print '已经没有 '+@table+'temp_设备分户增减变动统计表_附件_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备分户增减变动统计表_附件_last') and type='u')
exec('drop table temp_设备分户增减变动统计表_附件_last')
else 
print '已经没有 temp_设备分户增减变动统计表_附件_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备分户查询统计表_附件_last') and type='u')
exec('drop table '+@table+'temp_设备分户查询统计表_附件_last')
else 
print '已经没有 '+@table+'temp_设备分户查询统计表_附件_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备分户查询统计表_附件_last') and type='u')
exec('drop table temp_设备分户查询统计表_附件_last')
else 
print '已经没有 temp_设备分户查询统计表_附件_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_固定资产汇总表_s_zjall') and type='u')
exec('drop table '+@table+'temp_固定资产汇总表_s_zjall')
else 
print '已经没有 '+@table+'temp_固定资产汇总表_s_zjall'
if exists(select 1 from sysobjects where id = object_id('temp_固定资产汇总表_s_zjall') and type='u')
exec('drop table temp_固定资产汇总表_s_zjall')
else 
print '已经没有 temp_固定资产汇总表_s_zjall'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类增减变动统计表_附件_s_zjall') and type='u')
exec('drop table '+@table+'temp_分类增减变动统计表_附件_s_zjall')
else 
print '已经没有 '+@table+'temp_分类增减变动统计表_附件_s_zjall'
if exists(select 1 from sysobjects where id = object_id('temp_分类增减变动统计表_附件_s_zjall') and type='u')
exec('drop table temp_分类增减变动统计表_附件_s_zjall')
else 
print '已经没有 temp_分类增减变动统计表_附件_s_zjall'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_分类查询_在帐本期增加数_附件') and type='u')
exec('drop table '+@table+'temp_分类查询_在帐本期增加数_附件')
else 
print '已经没有 '+@table+'temp_分类查询_在帐本期增加数_附件'
if exists(select 1 from sysobjects where id = object_id('temp_分类查询_在帐本期增加数_附件') and type='u')
exec('drop table temp_分类查询_在帐本期增加数_附件')
else 
print '已经没有 temp_分类查询_在帐本期增加数_附件'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'资产情况表_按11大类') and type='u')
exec('drop table '+@table+'资产情况表_按11大类')
else 
print '已经没有 '+@table+'资产情况表_按11大类'
if exists(select 1 from sysobjects where id = object_id('资产情况表_按11大类') and type='u')
exec('drop table 资产情况表_按11大类')
else 
print '已经没有 资产情况表_按11大类'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'资产本年增量表_按取得方式') and type='u')
exec('drop table '+@table+'资产本年增量表_按取得方式')
else 
print '已经没有 '+@table+'资产本年增量表_按取得方式'
if exists(select 1 from sysobjects where id = object_id('资产本年增量表_按取得方式') and type='u')
exec('drop table 资产本年增量表_按取得方式')
else 
print '已经没有 资产本年增量表_按取得方式'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备经费科目统计表_last') and type='u')
exec('drop table '+@table+'temp_设备经费科目统计表_last')
else 
print '已经没有 '+@table+'temp_设备经费科目统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备经费科目统计表_last') and type='u')
exec('drop table temp_设备经费科目统计表_last')
else 
print '已经没有 temp_设备经费科目统计表_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'国有资产基本情况表') and type='u')
exec('drop table '+@table+'国有资产基本情况表')
else 
print '已经没有 '+@table+'国有资产基本情况表'
if exists(select 1 from sysobjects where id = object_id('国有资产基本情况表') and type='u')
exec('drop table 国有资产基本情况表')
else 
print '已经没有 国有资产基本情况表'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_使用方向统计表_last') and type='u')
exec('drop table '+@table+'temp_使用方向统计表_last')
else 
print '已经没有 '+@table+'temp_使用方向统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_使用方向统计表_last') and type='u')
exec('drop table temp_使用方向统计表_last')
else 
print '已经没有 temp_使用方向统计表_last'
--*******************************************************************************************************************************************************

if exists(select 1 from sysobjects where id = object_id(@table+'temp_设备来源统计表_last') and type='u')
exec('drop table '+@table+'temp_设备来源统计表_last')
else 
print '已经没有 '+@table+'temp_设备来源统计表_last'
if exists(select 1 from sysobjects where id = object_id('temp_设备来源统计表_last') and type='u')
exec('drop table temp_设备来源统计表_last')
else 
print '已经没有 temp_设备来源统计表_last'
--*******************************************************************************************************************************************************

--******************
delete from tables where 用户名=@table
end
if exists(select 1 from sysobjects where name = 'tables') 
drop table tables
else
print '报表清理完毕'