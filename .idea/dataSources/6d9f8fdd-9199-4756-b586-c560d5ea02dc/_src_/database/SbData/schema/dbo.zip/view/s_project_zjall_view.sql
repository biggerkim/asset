CREATE VIEW dbo.s_project_zjall_view
AS
SELECT TOP 100 PERCENT dbo.S_PROJECT.项目名称, dbo.S_PROJECT.项目负责人, 
      dbo.S_PROJECT.负责人编号, dbo.S_PROJECT.项目审核人, 
      dbo.S_PROJECT.审核日期, dbo.S_PROJECT.所属单位, dbo.S_PROJECT.审核, 
      dbo.S_PROJECT.创建人, dbo.S_PROJECT.创建日期, dbo.S_ZJALL.领用单位号, 
      dbo.S_PROJECT_ZJALL.仪器编号, dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, 
      dbo.S_ZJALL.规格, dbo.S_ZJALL.单价, dbo.S_ZJALL.厂家, dbo.S_ZJALL.出厂号, 
      dbo.S_ZJALL.购置日期, dbo.S_ZJALL.现状, dbo.S_ZJALL.存放地名称, 
      dbo.S_ZJALL.经费科目, dbo.S_ZJALL.使用方向, dbo.S_ZJALL.设备来源, 
      dbo.S_ZJALL.领用人, dbo.S_ZJALL.经手人, dbo.S_ZJALL.输入人, 
      dbo.S_ZJALL.单据号, dbo.S_ZJALL.入库时间, dbo.S_ZJALL.财务凭单, 
      dbo.S_ZJALL.记帐人, dbo.S_ZJALL.输入日期, dbo.S_ZJALL.分类号, 
      dbo.S_ZJALL.国标分类号, dbo.S_ZJALL.存放地编号, dbo.S_ZJALL.资产类别, 
      dbo.S_ZJALL.国标分类名, dbo.S_ZJALL.数量, dbo.S_ZJALL.国别, 
      dbo.S_ZJALL.国别码, dbo.S_ZJALL.人员编号, 
      dbo.S_PROJECT_ZJALL.输入人 AS 仪器添加人, 
      dbo.S_PROJECT_ZJALL.输入日期 AS 仪器添加日期, 
      dbo.S_PROJECT_ZJALL.projectId, dbo.S_PROJECT_ZJALL.id, 
      dbo.S_PROJECT_ZJALL.zjalldeleted, dbo.S_PROJECT.projectDeleted
FROM dbo.S_PROJECT INNER JOIN
      dbo.S_PROJECT_ZJALL ON 
      dbo.S_PROJECT.id = dbo.S_PROJECT_ZJALL.projectId INNER JOIN
      dbo.S_ZJALL ON dbo.S_PROJECT_ZJALL.仪器编号 = dbo.S_ZJALL.仪器编号
ORDER BY dbo.S_PROJECT.id
