CREATE VIEW dbo.s_zcjyk_view
AS
SELECT dbo.s_zcjyk.*, dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, dbo.S_ZJALL.规格, 
      dbo.S_ZJALL.单价, dbo.S_ZJALL.厂家, dbo.S_ZJALL.购置日期, 
      dbo.S_ZJALL.存放地名称, dbo.S_ZJALL.领用人, dbo.S_ZJALL.图片文件, 
      dbo.S_ZJALL.图片文件1
FROM dbo.s_zcjyk LEFT OUTER JOIN
      dbo.S_ZJALL ON dbo.s_zcjyk.仪器编号 = dbo.S_ZJALL.仪器编号
