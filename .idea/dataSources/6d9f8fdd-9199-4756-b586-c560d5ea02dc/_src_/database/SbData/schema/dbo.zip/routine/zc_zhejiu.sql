

CREATE procedure zc_zhejiu

as


 
-- 入账日期   0
-- 购置日期   1
-- 财务审核日 2


exec('insert into s_zhejiu (仪器编号) select 仪器编号 from s_zjall  where 折旧方式=1 and  not exists(select 仪器编号 from s_zhejiu where s_zjall.仪器编号=s_zhejiu.仪器编号)')
 
--SELECT 仪器编号 FROM S_BDK_DBF WHERE (YEAR(GETDATE()) = YEAR(变动日期)) AND (NOT EXISTS (SELECT 仪器编号 FROM s_zjall WHERE s_zjall.仪器编号 = s_bdk_dbf.仪器编号)) AND (现状 IN ('5', '6', '7', 'D', 'F','G', 'H')) AND (NOT EXISTS (SELECT 仪器编号 FROM s_zhejiu WHERE s_zhejiu.仪器编号 = s_bdk_dbf.仪器编号))
exec('insert into s_zhejiu (仪器编号) SELECT 仪器编号 FROM S_BDK_DBF WHERE 折旧方式=1  and  (YEAR(GETDATE()) = YEAR(变动日期)) AND (NOT EXISTS (SELECT 仪器编号 FROM s_zjall WHERE s_zjall.仪器编号 = s_bdk_dbf.仪器编号)) AND (现状 IN (''5'', ''6'', ''7'', ''D'', ''F'',''G'', ''H'')) AND (NOT EXISTS (SELECT 仪器编号 FROM s_zhejiu WHERE s_zhejiu.仪器编号 = s_bdk_dbf.仪器编号))')