
CREATE VIEW dbo.js_Logs
AS
SELECT dbo.S_ZJALL.领用单位号, dbo.JS_record_logs.仪器编号, dbo.S_ZJALL.仪器名称, 
      dbo.S_ZJALL.型号, dbo.S_ZJALL.规格, dbo.JS_record_logs.上机日期, 
      dbo.JS_record_logs.上机时间, dbo.JS_record_logs.下机时间, 
      dbo.JS_record_logs.上机机时, dbo.JS_record_logs.实验人数, 
      dbo.MK1.NR AS 实验者类别, dbo.JS_record_logs.上机内容, 
      dbo.JS_record_logs.输入人, dbo.JS_record_logs.输入日期, dbo.JS_record_logs.审核, 
      dbo.JS_record_logs.审核人, dbo.JS_record_logs.审核日期, 
      dbo.JS_record_logs.审核职工号, dbo.S_ZJALL.领用人, dbo.S_ZJALL.记帐人, 
      dbo.JS_record_logs.单据号, dbo.S_ZJALL.单价, dbo.S_ZJALL.厂家, 
      dbo.S_ZJALL.出厂号, dbo.JS_record_logs.IP, dbo.JS_record_logs.logsId
FROM dbo.JS_record_logs INNER JOIN
      dbo.S_ZJALL ON dbo.JS_record_logs.仪器编号 = dbo.S_ZJALL.仪器编号 INNER JOIN
      dbo.MK1 ON dbo.JS_record_logs.实验者类别 = dbo.MK1.BJ2 AND 
      dbo.MK1.BJ = '实验者类别'

