CREATE VIEW dbo.s_xq
AS
SELECT TOP 100 PERCENT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 40) 
      AS 校区名, 校编号 AS 校校区, 校名称 AS 校校区名
FROM dbo.MK1
WHERE (BJ = '校区')
ORDER BY LEFT(NR, 1)
