
CREATE VIEW dbo.S_TBSJ
AS
SELECT dbo.S_ZJALL.领用单位号, dbo.S_RYK.单位编号, dbo.S_ZJALL.领用人, 
      dbo.S_RYK.人员名, dbo.S_RYK.人员编号, dbo.S_ZJALL.字符字段2
FROM dbo.S_ZJALL INNER JOIN
      dbo.S_RYK ON dbo.S_ZJALL.领用单位号 = dbo.S_RYK.单位编号 AND 
      dbo.S_ZJALL.领用人 = dbo.S_RYK.人员名

