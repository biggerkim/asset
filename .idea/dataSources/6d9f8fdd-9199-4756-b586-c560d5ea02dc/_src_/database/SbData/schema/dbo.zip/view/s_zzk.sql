CREATE VIEW dbo.s_zzk
AS
SELECT TOP 100 PERCENT dbo.S_ZJALL.领用单位号, dbo.S_ZJALL.仪器编号, 
      dbo.S_ZJALL.仪器名称, dbo.S_ZJALL.型号, dbo.S_ZJALL.规格, dbo.S_ZJALL.厂家, 
      dbo.S_ZJALL.单价, dbo.S_ZJALL.出厂号, dbo.S_ZJALL.出厂日期, 
      dbo.S_ZJALL.购置日期, dbo.S_ZJALL.存放地名称, dbo.S_ZJALL.领用人, 
      dbo.S_ZJALL.经手人, dbo.S_ZJALL.输入人, dbo.S_ZJALL.记帐人, 
      dbo.S_ZJALL.财务凭单, dbo.S_ZJALL.输入日期, dbo.S_ZJALL.入库时间, 
      dbo.S_ZJALL.单据号, dbo.S_ZJALL.备注, dbo.S_ZJALL.设备号, dbo.S_ZJALL.科研号, 
      dbo.S_ZJALL.字符字段1 AS 发票号, dbo.S_ZJALL.字符字段2 AS 职工号, 
      dbo.S_ZJALL.国标分类号, dbo.S_ZJALL.存放地编号, dbo.S_ZJALL.分类号, 
      dbo.S_ZJALL.使用单位号, dbo.S_ZJALL.保修期限, dbo.S_ZJALL.国别, 
      dbo.S_ZJALL.国别码, dbo.S_ZJALL.编号, dbo.S_ZJALL.图文名称, 
      dbo.S_ZJALL.图片文件1, dbo.S_ZJALL.图片文件, dbo.S_ZJALL.图文名称1, 
      dbo.s_xianzhuang.name AS 现状, dbo.s_jingfei.name AS 经费科目, 
      dbo.s_laiyuan.name AS 设备来源, dbo.s_syfangx.name AS 使用方向
FROM dbo.S_ZJALL INNER JOIN
      dbo.s_xianzhuang ON dbo.S_ZJALL.现状 = dbo.s_xianzhuang.code INNER JOIN
      dbo.s_jingfei ON dbo.S_ZJALL.经费科目 = dbo.s_jingfei.code INNER JOIN
      dbo.s_laiyuan ON dbo.S_ZJALL.设备来源 = dbo.s_laiyuan.code INNER JOIN
      dbo.s_syfangx ON dbo.S_ZJALL.使用方向 = dbo.s_syfangx.code
ORDER BY dbo.S_ZJALL.领用单位号 + dbo.S_ZJALL.分类号 + dbo.S_ZJALL.仪器编号
