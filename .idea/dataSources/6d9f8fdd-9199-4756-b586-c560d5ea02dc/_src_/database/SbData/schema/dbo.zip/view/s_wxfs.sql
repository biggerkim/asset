CREATE VIEW dbo.s_wxfs
AS
SELECT BJ, NR, LEFT(NR, 1) AS code, SUBSTRING(NR, 3, 30) AS 维修方式名, 
      校编号 AS 校维修方式, 校名称 AS 校维修方式名
FROM dbo.MK1
WHERE (BJ = '维修方式')
