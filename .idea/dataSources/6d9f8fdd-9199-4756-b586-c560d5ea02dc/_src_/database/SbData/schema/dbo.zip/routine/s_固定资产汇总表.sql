

CREATE procedure s_固定资产汇总表 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_固定资产汇总表_s_zjall') and type='u')
exec('drop table '+@yh+'temp_固定资产汇总表_s_zjall')
else 
print '没有 '+@yh+'temp_固定资产汇总表_s_zjall'

if exists(select 1 from sysobjects where name = 'temp_固定资产汇总表_s_zjall') 
drop table temp_固定资产汇总表_s_zjall
else 
print '没有 temp_固定资产汇总表_s_zjall'
exec('select * into '+@yh+'temp_固定资产汇总表_s_zjall from (
--目前在帐设备
--本期在帐数(非年末数，本期增加)
select 分类号=left(分类号,4),现状,总数量=count(*),总价=sum(总价),单位标志=''*'',入库时间,经费科目,单据号=right(rtrim(单据号),4) from '+@yh+'temp_固定资产汇总表初_s_zjall where 分类号<>''附件'' group by left(分类号,4),现状 ,入库时间,经费科目,单据号
union all
--目前变动库里的非增减值
--（非内部调拨、增减值）本期增加数

select 分类号=left(分类号,4),现状=''zj'',总数量=count(*),总价=sum(单价),单位标志=''*'',入库时间,经费科目,单据号=right(单据号,4) from s_bdk_dbf where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') group by left(分类号,4),入库时间,经费科目,right(单据号,4)
union all
--目前变动库里的增减值资产
--（非年末数）本期增值数
select 分类号=left(分类号,4),现状=''zz'',总数量=0,总价=sum(变动单价),单位标志=''*'',入库时间,经费科目,单据号=right(单据号,4) from s_bdk_dbf where  变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 group by left(分类号,4),入库时间,经费科目,right(单据号,4)
union all
--本期增加数里减值数
select 分类号=left(分类号,4),现状=''bj'',总数量=0,总价=-sum(变动单价),单位标志=''*'',入库时间,经费科目,单据号=right(单据号,4) from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 group by left(分类号,4),入库时间,经费科目,right(单据号,4)

union all
--本期增加数里增值数
select 分类号=left(分类号,4),现状=''bz'',总数量=0,总价=sum(变动单价),单位标志=''*'',入库时间,经费科目,单据号=right(单据号,4) from s_bdk_dbf where  入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 group by left(分类号,4),入库时间,经费科目,right(单据号,4)

union all
--本期增加数里增值数
select 分类号=''附件'',现状,总数量=count(*),总价=sum(附件单价),单位标志=''*'',入库时间,经费科目,单据号=right(rtrim(单据号),4) from S_FJ_DBF where 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' group by 现状 ,入库时间,经费科目,right(rtrim(单据号),4)

) b')
