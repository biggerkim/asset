CREATE VIEW dbo.S_FJ_VIEW
AS
SELECT TOP 100 PERCENT dbo.S_FJ.领用单位号, dbo.s_dw_view.单位名称, 
      dbo.S_FJ.附件编号, dbo.S_FJ.分类号, dbo.S_FJ.附件名称, dbo.S_FJ.附型号规格, 
      dbo.S_FJ.附件单价, dbo.S_FJ.厂家, dbo.S_FJ.出厂号, dbo.S_FJ.出厂日期, 
      dbo.S_FJ.购置日期, dbo.S_FJ.保修期限, dbo.S_FJ.现状, dbo.S_XZ.现状名, 
      dbo.S_FJ.领用人, dbo.S_FJ.输入人, dbo.S_FJ.输入日期, dbo.S_FJ.经手人, 
      dbo.S_FJ.经费科目, dbo.S_JFKM.经费科目名, dbo.S_FJ.使用方向, 
      dbo.S_SYFX.使用方向名, dbo.S_FJ.设备来源, dbo.S_SBLY.设备来源名, 
      dbo.S_FJ.科研号, dbo.S_FJ.设备号, dbo.S_FJ.附件进口价, dbo.S_FJ.国标分类号, 
      dbo.S_FJ.国标分类名, dbo.S_FJ.资产类别, dbo.s_zclb.资产类别名, dbo.S_FJ.单据号, 
      dbo.S_FJ.入库时间, dbo.S_FJ.存放地编号, dbo.S_FJ.存放地名称, 
      dbo.S_FJ.字符字段1, dbo.S_FJ.字符字段2, dbo.S_FJ.字符字段3, dbo.S_FJ.字符字段4, 
      dbo.S_FJ.字符字段5, dbo.S_FJ.数字字段1, dbo.S_FJ.数字字段2, dbo.S_FJ.数字字段3, 
      dbo.S_FJ.数字字段4, dbo.S_FJ.国别, dbo.S_FJ.国别码, dbo.S_FJ.使用单位号, 
      dbo.S_FJ.零配件, dbo.S_FJ.标志, dbo.S_FJ.校区, dbo.s_xq.校区名, dbo.S_FJ.审核, 
      dbo.s_sh.审核名, dbo.S_FJ.退回原因, dbo.S_FJ.初退回原因, dbo.S_FJ.初审, 
      dbo.s_cs.初审名, dbo.S_FJ.初审日期, dbo.S_FJ.初审人, dbo.S_FJ.图片文件, 
      dbo.S_FJ.图文名称, dbo.S_FJ.图片文件1, dbo.S_FJ.图文名称1, dbo.S_FJ.图片文件2, 
      dbo.S_FJ.图文名称2, dbo.S_FJ.图片文件3, dbo.S_FJ.图文名称3, dbo.S_FJ.人员编号, 
      dbo.S_FJ.财政分类ID, dbo.S_FJ.财政大类ID, dbo.S_FJ.六类资产, dbo.S_FJ.供货商, 
      dbo.S_FJ.发票号, dbo.S_FJ.字符字段6, dbo.S_FJ.字符字段7, dbo.S_FJ.字符字段8, 
      dbo.S_FJ.字符字段9, dbo.S_FJ.字符字段10, dbo.S_FJ.日期字段1, 
      dbo.S_FJ.日期字段2, dbo.S_FJ.代码字段1, dbo.S_FJ.代码字段2, dbo.S_FJ.代码字段3, 
      dbo.S_FJ.申请原因, dbo.S_FJ.申请人, dbo.S_FJ.申请日期, dbo.S_FJ.申请负责人, 
      dbo.S_FJ.折旧方式, dbo.s_zjfs.折旧方式名, dbo.S_FJ.使用年限, 
      dbo.S_FJ.累计折旧额, dbo.S_FJ.折旧残值, dbo.S_FJ.净值, dbo.S_FJ.计量单位, 
      dbo.S_FJ.变动领用人, dbo.S_FJ.变人员编号, dbo.S_FJ.变动地名称, 
      dbo.S_FJ.变动地编号, dbo.S_FJ.变动单据号, dbo.S_FJ.财政内主号, 
      dbo.S_FJ.财政资产号, dbo.S_FJ.财审内头号, dbo.S_FJ.财审资头号, 
      dbo.S_FJ.财审内体号, dbo.S_FJ.财处内头号, dbo.S_FJ.财处资头号, 
      dbo.S_FJ.财处内体号, dbo.S_FJ.接收主管, dbo.S_FJ.收购单位, dbo.S_FJ.修改标志, 
      dbo.S_FJ.价值类型, dbo.s_jzlx.价值类型名, dbo.S_FJ.ID, dbo.S_FJ.采购形式, 
      dbo.s_cgxs.采购形式名, dbo.s_cgxs.校采购形式, dbo.s_cgxs.校采购形式名, 
      dbo.s_jzlx.校价值类型, dbo.s_jzlx.校价值类型名, dbo.s_xq.校校区, 
      dbo.s_xq.校校区名, dbo.S_XZ.校现状, dbo.S_XZ.校现状名, dbo.s_zjfs.校折旧方式, 
      dbo.s_zjfs.校折旧方式名, dbo.S_SBLY.校设备来源, dbo.S_SBLY.校设备来源名, 
      dbo.S_SYFX.校使用方向, dbo.S_SYFX.校使用方向名, dbo.S_JFKM.校经费科目, 
      dbo.S_JFKM.校经费科目名, dbo.s_dw_view.校单位编号, dbo.s_dw_view.校单位名称, 
      dbo.s_dw_view.单位性质, dbo.s_dw_view.单位性质名, dbo.s_dw_view.校单位性质, 
      dbo.s_dw_view.校单位性质名, dbo.S_FJ.联系方式, dbo.S_FJ.字符字段11, 
      dbo.S_FJ.字符字段12, dbo.S_FJ.字符字段13, dbo.S_FJ.字符字段14, 
      dbo.S_FJ.字符字段15, dbo.S_FJ.字符字段16, dbo.S_FJ.数字字段5, 
      dbo.S_FJ.数字字段6, dbo.S_FJ.数字字段7, dbo.S_FJ.数字字段8
FROM dbo.S_FJ LEFT OUTER JOIN
      dbo.s_dw_view ON 
      dbo.S_FJ.领用单位号 = dbo.s_dw_view.单位编号 LEFT OUTER JOIN
      dbo.S_XZ ON dbo.S_FJ.现状 = dbo.S_XZ.code LEFT OUTER JOIN
      dbo.S_JFKM ON dbo.S_FJ.经费科目 = dbo.S_JFKM.code LEFT OUTER JOIN
      dbo.S_SYFX ON dbo.S_FJ.使用方向 = dbo.S_SYFX.code LEFT OUTER JOIN
      dbo.S_SBLY ON dbo.S_FJ.设备来源 = dbo.S_SBLY.code LEFT OUTER JOIN
      dbo.s_zclb ON dbo.S_FJ.资产类别 = dbo.s_zclb.code LEFT OUTER JOIN
      dbo.s_xq ON dbo.S_FJ.校区 = dbo.s_xq.code LEFT OUTER JOIN
      dbo.s_sh ON dbo.S_FJ.审核 = dbo.s_sh.code LEFT OUTER JOIN
      dbo.s_cs ON dbo.S_FJ.初审 = dbo.s_cs.code LEFT OUTER JOIN
      dbo.s_zjfs ON dbo.S_FJ.折旧方式 = dbo.s_zjfs.code LEFT OUTER JOIN
      dbo.s_jzlx ON dbo.S_FJ.价值类型 = dbo.s_jzlx.code LEFT OUTER JOIN
      dbo.s_cgxs ON dbo.S_FJ.采购形式 = dbo.s_cgxs.code CROSS JOIN
      dbo.s_cwsh
ORDER BY dbo.S_FJ.领用单位号 + dbo.S_FJ.分类号 + dbo.S_FJ.附件编号
