
CREATE VIEW dbo.S_BHFW
AS
SELECT 领用单位号, 仪器名称, 型号, 规格, 单价, 购置日期, MIN(仪器编号) AS 最小编号, 
      MAX(仪器编号) AS 最大编号
FROM dbo.S_ZJALL
WHERE (编号 = '')
GROUP BY 领用单位号, 仪器名称, 型号, 规格, 单价, 购置日期

