CREATE VIEW dbo.s_dw_view
AS
SELECT dbo.S_DW.单位编号, dbo.S_DW.单位名称, dbo.S_DW.单位简称, 
      dbo.S_DW.单位简码, dbo.S_DW.建立年份, dbo.S_DW.经费科目值, 
      dbo.S_JFKM.经费科目名, dbo.S_JFKM.校经费科目, dbo.S_JFKM.校经费科目名, 
      dbo.S_DW.校区, dbo.s_xq.校区名, dbo.s_xq.校校区, dbo.s_xq.校校区名, 
      dbo.S_DW.使用方向值, dbo.S_SYFX.使用方向名, dbo.S_SYFX.校使用方向, 
      dbo.S_SYFX.校使用方向名, dbo.S_DW.校单位编号, dbo.S_DW.校单位名称, 
      dbo.S_DW.反馈信息, dbo.S_DW.上报单位名, dbo.S_DW.标志, dbo.S_DW.单位标志, 
      dbo.S_DW.ID, dbo.S_DW.单位性质, dbo.s_dwxz.单位性质名, 
      dbo.s_dwxz.校单位性质, dbo.s_dwxz.校单位性质名
FROM dbo.S_DW LEFT OUTER JOIN
      dbo.S_JFKM ON dbo.S_DW.经费科目值 = dbo.S_JFKM.code LEFT OUTER JOIN
      dbo.S_SYFX ON dbo.S_DW.使用方向值 = dbo.S_SYFX.code LEFT OUTER JOIN
      dbo.s_xq ON dbo.S_DW.校区 = dbo.s_xq.code LEFT OUTER JOIN
      dbo.s_dwxz ON dbo.S_DW.单位性质 = dbo.s_dwxz.code
