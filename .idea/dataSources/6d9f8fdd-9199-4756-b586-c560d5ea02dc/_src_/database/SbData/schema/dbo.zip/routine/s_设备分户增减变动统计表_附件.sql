

create procedure s_设备分户增减变动统计表_附件 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@tjjb1 varchar(30),@tjfs varchar(1),@yh varchar(50),@condition varchar(100)
as
declare @lydw2 varchar(10)
declare @tjjb varchar(1)
declare @value int
declare @i int 

set @tjjb='f'
if @lydw='00'
begin
set @lydw=''
set @lydw2='00'
end

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件') and type='u')
exec('drop table '+@yh+'temp_设备分户增减变动统计表_附件')
else 
print '没有 '+@yh+'temp_设备分户增减变动统计表_附件'
if exists(select 1 from sysobjects where name = 'temp_设备分户增减变动统计表_附件') 
drop table temp_设备分户增减变动统计表_附件
else 
print '没有 temp_设备分户增减变动统计表_附件'
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分户增减变动统计表_附件_s_zjall') and type='u')
exec('drop table '+@yh+'temp_分户增减变动统计表_附件_s_zjall')
else 
print '没有 '+@yh+'temp_分户增减变动统计表_附件_s_zjall'
if exists(select 1 from sysobjects where name = 'temp_分户增减变动统计表_附件_s_zjall') 
drop table temp_分户增减变动统计表_附件_s_zjall
else 
print '没有 temp_分户增减变动统计表_附件_s_zjall'
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('drop table '+@yh+'temp_设备分户增减变动统计表_附件_last')
else 
print '没有 '+@yh+'temp_设备分户增减变动统计表_附件_last'
if exists(select 1 from sysobjects where name = 'temp_设备分户增减变动统计表_附件_last') 
drop table temp_设备分户增减变动统计表_附件_last
else 
print '没有 temp_设备分户增减变动统计表_附件_last'


exec('select * into '+@yh+'temp_分户增减变动统计表_附件_s_zjall from (
--目前在帐设备
--主机本期前入账，附件本期后入账（期末数该减附件）
select 领用单位号=b.领用单位号,现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and  a.入库时间<'''+@qsrq+''' and b.入库时间>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--主机本期前入账，附件本期入账（本期增加的其他该加附件）
select 领用单位号=b.领用单位号,现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--主机本期入账，附件本期入账（购置应该减附件，本期增加的其他该加附件）
select 领用单位号=b.领用单位号,现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--主机本期入账，附件本期后入账（期末应该减附件，购置应该减附件）
select 领用单位号=b.领用单位号,现状=''gzqm'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_zjall a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>'''+@jzrq+''' and b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--减少
--主机本期前入账，附件本期入账，起始日期后变动减少（本期增加的其他里应该增加附件）
select 领用单位号=b.领用单位号,现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 <'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期>='''+@qsrq+''' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and  b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--主机截止日期前入账，附件本期后入账，本期后变动减少（期末数应该减附件）
select 领用单位号=b.领用单位号,现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<='''+@jzrq+''' and b.入库时间>'''+@jzrq+''' and a.变动日期>'''+@jzrq+''' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and  b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--主机本期入账，附件本期入账，起始时间后变动减少（购置减附件，其它加附件）
select 领用单位号=b.领用单位号,现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期>='''+@qsrq+''' and (a.现状=''7'' or a.现状=''5'' or a.现状=''6'' or a.现状=''D'' or a.现状=''E'' or a.现状=''F'' or a.现状=''G'' or a.现状=''H'') and  b.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by b.领用单位号
union all
--内部转移(附件入库时间<主机变动日期)
--主机本期前入账，附件本期入账，起始时间后变动转移（本期增加的其它加附件）
select 领用单位号=a.领用单位号,现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期>='''+@qsrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by a.领用单位号
union all
--主机本期前入账，附件本期后入账，本期后变动转移（期末数减附件）
select 领用单位号=a.领用单位号,现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间>'''+@jzrq+''' and a.变动日期>'''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by a.领用单位号
union all
--主机本期入账，附件起始时间后入账，本期变动转移（购置减附件，其他加附件）
select 领用单位号=a.领用单位号,现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>='''+@qsrq+''' and a.变动日期 >='''+@qsrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by a.领用单位号
union all
--主机本期入账，附件本期后入账，本期后变动转移（购置减附件，期末减附件）
select 领用单位号=a.领用单位号,现状=''gzqm'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>'''+@jzrq+''' and a.变动日期 >'''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.领用单位号 like '''+@lydw+'%'' and '+@condition+' group by a.领用单位号
union all
--内部转移(附件入库时间>主机变动日期)
--主机本期前入账，附件本期入账，截止日期前变动转移（本期增加的其它加附件）
select 领用单位号=a.转入单位,现状=''bzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期 >'''+@jzrq+''' and b.入库时间>a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位
union all
--主机本期前入账，附件本期后入账（期末数减附件）
select 领用单位号=a.转入单位,现状=''@'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间<'''+@qsrq+''' and b.入库时间 >'''+@jzrq+''' and b.入库时间>a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位
union all
--主机本期入账，附件本期入账,本期变动转移（购置减附件,其他加附件）
select 领用单位号=a.转入单位,现状=''gzqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and a.变动日期 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间>a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位
union all
--主机本期入账，附件本期后入账（购置减附件,期末减附件）
select 领用单位号=a.转入单位,现状=''gzqm'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 >'''+@jzrq+''' and b.入库时间>a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位
union all
--主机本期入账，附件本期后入账（购置减附件,期末减附件）
select 领用单位号=a.转入单位,现状=''gjqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位
union all
--主机本期入账，附件本期入账,本期变动转移（购置减附件,其他加附件）
select 领用单位号=a.转入单位,现状=''ggqt'',总数量=0,总价=sum(b.附件单价),单位标志=''*'' from s_fj_dbf b,s_bdk_dbf a where left(b.附件编号,8)=a.仪器编号 and a.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间 between '''+@qsrq+''' and '''+@jzrq+''' and b.入库时间<a.变动日期 and (a.现状=''C'') and  a.转入单位 like '''+@lydw+'%'' and '+@condition+' group by a.转入单位

) b')

if @lydw2='00'
begin
if @tjjb='a'
begin
exec('select 领用单位号=''00'',现状,总数量=sum(总数量),总价=sum(总价),单位标志=''1'' into '+@yh+'temp_设备分户增减变动统计表_附件 from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by  现状')
end
else if @tjjb='b'
begin
exec('select 领用单位号=left(a.领用单位号,2),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,2),现状')
end
else if @tjjb='c'
begin
exec('select 领用单位号=left(a.领用单位号,4),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,4),现状')
end
else if @tjjb='d'
begin
exec('select 领用单位号=left(a.领用单位号,6),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,6),现状')
end
else if @tjjb='e'
begin
exec('select 领用单位号=left(a.领用单位号,8),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,8),现状')
end
else if @tjjb='f'
begin
--只统计末级
exec('select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''*'' into '+@yh+'temp_设备分户增减变动统计表_附件 from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状
union
--只统计一级
select 领用单位号=''00'',现状,总数量=sum(总数量),总价=sum(总价),单位标志=''1'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 现状
union
--只统计二级
select 领用单位号=left(a.领用单位号,2),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''2'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''2'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,2),现状
union
--只统计三级
select 领用单位号=left(a.领用单位号,4),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''3'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''3'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,4),现状
union
--只统计四级
select 领用单位号=left(a.领用单位号,6),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''4'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''4'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,6),现状
union
--只统计五级
select 领用单位号=left(a.领用单位号,8),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''5'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''5'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,8),现状
union
--只统计六级
select 领用单位号=left(a.领用单位号,10),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''6'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''6'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,10),现状')
--判断是否统计数据为零的单位
if @tjfs='1'
begin
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志 from s_dw where 单位标志=''*'' and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''2'' from s_dw where len(单位编号)=2 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''3'' from s_dw where len(单位编号)=4 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''4'' from s_dw where len(单位编号)=6 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''5'' from s_dw where len(单位编号)=8 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
end

end
end
else 
if @tjjb='a'
begin
exec('select 领用单位号=left(a.领用单位号,2),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,2),现状')
end
else if @tjjb='b'
begin
exec('select 领用单位号=left(a.领用单位号,2),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,2),现状')
end
else if @tjjb='c'
begin
exec('select 领用单位号=left(a.领用单位号,4),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,4),现状')
end
else if @tjjb='d'
begin
exec('select 领用单位号=left(a.领用单位号,6),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,6),现状')
end
else if @tjjb='e'
begin
exec('select 领用单位号=left(a.领用单位号,8),现状,总数量=sum(a.总数量),总价=sum(a.总价) into '+@yh+'temp_设备分户增减变动统计表_附件 from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价) from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,8),现状')
end
else if @tjjb='f'
begin
--只统计末级
exec('select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''*'' into '+@yh+'temp_设备分户增减变动统计表_附件 from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状
union

--只统计二级
select 领用单位号=left(a.领用单位号,2),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''2'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''2'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,2),现状
union
--只统计三级
select 领用单位号=left(a.领用单位号,4),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''3'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''3'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,4),现状
union
--只统计四级
select 领用单位号=left(a.领用单位号,6),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''4'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''4'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,6),现状
union
--只统计五级
select 领用单位号=left(a.领用单位号,8),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''5'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''5'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,8),现状
union
--只统计六级
select 领用单位号=left(a.领用单位号,10),现状,总数量=sum(a.总数量),总价=sum(a.总价),单位标志=''6'' from (select 领用单位号,现状,总数量=sum(总数量),总价=sum(总价),单位标志=''6'' from '+@yh+'temp_分户增减变动统计表_附件_s_zjall group by 领用单位号,现状) a group by left(a.领用单位号,10),现状')
--判断是否统计数据为零的单位
if @tjfs='1'
begin
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志 from s_dw where 单位标志=''*'' and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''2'' from s_dw where len(单位编号)=2 and 单位编号<>''00'' and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''3'' from s_dw where len(单位编号)=4 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''4'' from s_dw where len(单位编号)=6 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件 select 领用单位号=单位编号,现状=''@'',总数量=0,总价=0,单位标志=''5'' from s_dw where len(单位编号)=8 and 单位编号 not in (select 单位编号=领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件) and 单位编号 like '''+@lydw+'%''')
end

end
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_分户增减变动统计表_附件_s_zjall') and type='u')
exec('drop table '+@yh+'temp_分户增减变动统计表_附件_s_zjall')
else 
print '没有 '+@yh+'temp_分户增减变动统计表_附件_s_zjall'

while len(@tjjb1) > 0 
begin 
SELECT @i = Charindex(',',@tjjb1) 
set @value = cast(SUBSTRING ( @tjjb1 , 1 , @i-1 ) as int) 
print @value 
print  len(@tjjb1)
if @value=1
begin
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
 print '00 级已经统计过'
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where 领用单位号=''00'' and 单位标志=''1''')
end
if @value=2
begin
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件_last select *  from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=2 and 领用单位号<>''00'' and (单位标志=''2'' or  单位标志=''*'')) and 领用单位号 not in (select 领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last)')
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=2 and 领用单位号<>''00'' and (单位标志=''2'' or 单位标志=''*''))')

end

if @value=3
begin
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件_last select *  from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=4 and (单位标志=''3'' or  单位标志=''*'') or len(领用单位号)=2 and 单位标志=''*'') and 领用单位号 not in (select 领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last)')
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=4 and (单位标志=''3'' or  单位标志=''*'') or len(领用单位号)=2 and 单位标志=''*'')')

end

if @value=4
begin

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件_last select * from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=6 and (单位标志=''4'' or  单位标志=''*'') or len(领用单位号)=4 and 单位标志=''*'' or len(领用单位号)=2 and 单位标志=''*'') and 领用单位号 not in (select 领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last)')
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=6 and (单位标志=''4'' or  单位标志=''*'') or len(领用单位号)=4 and 单位标志=''*'' or len(领用单位号)=2 and 单位标志=''*'')')


end

if @value=5
begin
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件_last select * from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=8 and (单位标志=''5'' or  单位标志=''*'') or len(领用单位号)=6 and 单位标志=''*'' or len(领用单位号)=4 and 单位标志=''*'' or len(领用单位号)=2 and 单位标志=''*'') and 领用单位号 not in (select 领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last)')
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where (len(领用单位号)=8 and (单位标志=''5'' or  单位标志=''*'') or len(领用单位号)=6 and 单位标志=''*'' or len(领用单位号)=4 and 单位标志=''*'' or len(领用单位号)=2 and 单位标志=''*'')')

end

if @value=6
begin
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件_last') and type='u')
exec('insert into '+@yh+'temp_设备分户增减变动统计表_附件_last select * from '+@yh+'temp_设备分户增减变动统计表_附件 where 单位标志=''*'' and 领用单位号 not in (select 领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last)')
else
exec('select * into '+@yh+'temp_设备分户增减变动统计表_附件_last from '+@yh+'temp_设备分户增减变动统计表_附件 where 单位标志=''*''')

end

set @tjjb1 = SUBSTRING ( @tjjb1 , @i+1 , len(@tjjb1)-@i ) 
end 

if exists(select 1 from sysobjects where id = object_id(@yh+'temp_设备分户增减变动统计表_附件') and type='u')
exec('drop table '+@yh+'temp_设备分户增减变动统计表_附件')
else 
print '没有 '+@yh+'temp_设备分户增减变动统计表_附件'

exec('delete from '+@yh+'temp_设备分户增减变动统计表_附件_last where 领用单位号 in (
select a.领用单位号 from '+@yh+'temp_设备分户增减变动统计表_附件_last a,'+@yh+'temp_设备分户增减变动统计表_附件_last b where a.领用单位号=b.领用单位号 and a.现状=b.现状 and a.总数量=b.总数量 and a.总价=b.总价 and a.单位标志<>''*'' and b.单位标志=''*''
)and 单位标志<>''*''')
exec('update '+@yh+'temp_设备分户增减变动统计表_附件_last set 总价=0 where 总价 is null')
exec('update '+@yh+'temp_设备分户增减变动统计表_附件_last set 总数量=0 where 总数量 is null')



