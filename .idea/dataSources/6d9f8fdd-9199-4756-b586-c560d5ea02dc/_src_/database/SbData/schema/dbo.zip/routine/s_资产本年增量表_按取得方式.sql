

create procedure s_资产本年增量表_按取得方式 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50),@condition varchar(100)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_资产本年增量表_按取得方式_s_zjall') and type='u')
exec('drop table '+@yh+'temp_资产本年增量表_按取得方式_s_zjall')
else 
print '没有 '+@yh+'temp_资产本年增量表_按取得方式_s_zjall'

if exists(select 1 from sysobjects where name = 'temp_资产本年增量表_按取得方式_s_zjall') 
drop table temp_资产本年增量表_按取得方式_s_zjall
else 
print '没有 temp_资产本年增量表_按取得方式_s_zjall'
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg') and type='u')
exec('drop table '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg')
else 
print '没有 '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg'

if exists(select 1 from sysobjects where name = 'temp_资产本年增量表_按取得方式_s_zjall_tfg') 
drop table temp_资产本年增量表_按取得方式_s_zjall_tfg
else 
print '没有 temp_资产本年增量表_按取得方式_s_zjall_tfg'
--***************
--测试用例
--declare @qsrq varchar(30),@jzrq varchar(30),@lydw varchar(10),@yh varchar(50)
--set @qsrq='1900-01-01'
--set @jzrq='2010-12-31'
--set @lydw=''
--set @yh='管理员'
--exec('drop table '+@yh+'temp_资产本年增量表_按取得方式_s_zjall')
--**************

exec('select * into '+@yh+'temp_资产本年增量表_按取得方式_s_zjall from (
--目前在帐设备
--(年末数)
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,单位标志=''*'' from s_zjall where (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--本期在帐数(非年末数，本期增加)
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,单位标志=''*'' from s_zjall where (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=count(*),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期增加数

select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zj'',总数量=count(*),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期减少数

select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=count(*),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价
union all
--目前变动库里的增减值资产
--（年末数）
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非年末数）本期增值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zz'',总数量=0,总价=sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
--（非年末数）本期减值数
union all
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''jz'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--本期增加数里减值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bj'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

union all
--本期增加数里增值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bz'',总数量=0,总价=sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)<>''01'' and left(国标分类号,2)<>''02'' and left(国标分类号,2)<>''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

) b')
--*************************************************************************生成土地房屋构筑物
exec('select * into '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg from (
--目前在帐设备
--(年末数)
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=sum(数字字段1),总价=sum(单价),单价=单价,单位标志=''*'' from s_zjall where (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--本期在帐数(非年末数，本期增加)
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=sum(数字字段1),总价=sum(单价),单价=单价,单位标志=''*'' from s_zjall where (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价 
union all
--目前变动库里的非增减值
--（年末数）非内部调拨、增减值
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=sum(数字字段1),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间<='''+@jzrq+''' and 变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期增加数

select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zj'',总数量=sum(数字字段1),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非内部调拨、增减值）本期减少数

select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状,总数量=sum(数字字段1),总价=sum(单价),单价=单价,单位标志=''*'' from s_bdk_dbf where (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and (现状=''7'' or 现状=''5'' or 现状=''6'' or 现状=''D'' or 现状=''E'' or 现状=''F'' or 现状=''G'' or 现状=''H'') and '+@condition+' group by left(国标分类号,2),国标分类号,现状,单价
union all
--目前变动库里的增减值资产
--（年末数）
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''@'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  入库时间<='''+@jzrq+''' and  变动日期>'''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--（非年末数）本期增值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''zz'',总数量=0,总价=sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
--（非年末数）本期减值数
union all
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''jz'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 变动日期>='''+@qsrq+''' and 变动日期<='''+@jzrq+''' and 领用单位号 like '''+@lydw+'%''  and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价
union all
--本期增加数里减值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bj'',总数量=0,总价=-sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价<0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

union all
--本期增加数里增值数
select 序列1=''aaaaaaaa'',序列2=''aaaaaaaa'',序列3=''aaaaaaaa'',国标分类号=left(国标分类号,2),国标分类号0=国标分类号,现状=''bz'',总数量=0,总价=sum(变动单价),单价=0,单位标志=''*'' from s_bdk_dbf where  (left(国标分类号,2)=''01'' or left(国标分类号,2)=''02'' or left(国标分类号,2)=''03'') and 入库时间>='''+@qsrq+''' and 入库时间<='''+@jzrq+''' and 变动日期>='''+@qsrq+''' and 领用单位号 like '''+@lydw+'%'' and 变动单价>0 and '+@condition+' group by left(国标分类号,2),国标分类号,单价

) c')

--报表输出条件
--土地  序列1=10 
--生产用地 序列2 =11 
--交通邮电用地 序列2 =12 
--办公及业务用地 序列2 =13 
--市政公用设施用地 序列2=14
--生活及服务业用地 序列2=15
--科学研究用地    序列2=16
--文教、体育及医疗卫生用地 序列2=17
--特殊用地 序列2=18
--其他用地 序列2=19
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列1=''10'' where 国标分类号=''01''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''11'' where 序列1=''10'' and left(国标分类号0,3)=''011''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''12'' where 序列1=''10'' and left(国标分类号0,3)=''012''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''13'' where 序列1=''10'' and left(国标分类号0,3)=''013''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''14'' where 序列1=''10'' and left(国标分类号0,3)=''014''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''15'' where 序列1=''10'' and left(国标分类号0,3)=''015''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''16'' where 序列1=''10'' and left(国标分类号0,3)=''016''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''17'' where 序列1=''10'' and left(国标分类号0,3)=''017''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''18'' where 序列1=''10'' and left(国标分类号0,3)=''018''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''19'' where 序列1=''10'' and left(国标分类号0,3)=''019''')

--房屋及构筑物  序列1=20 
--生产用房  序列2=21 
--交通邮电用房  序列2=22 
--办公用房  序列2=23
--科研、气象用房 序列2=24
--文化教育用房 序列2=25
--医疗卫生体育用房 序列2=26
--特殊用房  序列2=27
--生活、娱乐、市政公共设施、服务业用房 序列2=28
--其中：职工宿舍 序列3=2801
--其它用房 序列2=29
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列1=''20'' where (国标分类号=''02'' or 国标分类号=''03'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''21'' where 序列1=''20'' and left(国标分类号0,3)=''021''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''22'' where 序列1=''20'' and left(国标分类号0,3)=''022''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''23'' where 序列1=''20'' and left(国标分类号0,3)=''023''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''24'' where 序列1=''20'' and left(国标分类号0,3)=''024''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''25'' where 序列1=''20'' and left(国标分类号0,3)=''025''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''26'' where 序列1=''20'' and left(国标分类号0,3)=''026''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''27'' where 序列1=''20'' and left(国标分类号0,3)=''027''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''28'' where 序列1=''20'' and left(国标分类号0,3)=''028''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列3=''2801'' where 序列2=''28'' and left(国标分类号0,6)=''028101''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg set 序列2=''29'' where 序列1=''20'' and left(国标分类号0,3)=''029''')

--通用设备 序列1=30
--单价20万元（含）以上50万元以下 序列2=31
--单价50万元（含）以上100万元以下 序列2=32
--单价100万元（含）以上200万元以下 序列2=33
--单价200万元（含）以上800万元以下 序列2=34
--单价800万元（含）以上 序列2=35

exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''30'' where (国标分类号 between ''06'' and ''21'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''30'' and 单价>=200000  and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''30'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''30'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''30'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''30'' and 单价>=8000000')
--专用设备 序列1=40
--单价20万元（含）以上50万元以下 序列2=41
--单价50万元（含）以上100万元以下 序列2=42
--单价100万元（含）以上200万元以下 序列2=43
--单价200万元（含）以上800万元以下 序列2=44
--单价800万元（含）以上 序列2=45
--其中：复印机  序列3=4001
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''40'' where (国标分类号 between ''25'' and ''47'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''40'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''40'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''40'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''40'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''40'' and 单价>=8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''4001'' where 序列1=''40'' and left(国标分类号0,6)=''464401''')

--交通运输设备 序列1=50
--汽车 序列2=51
--载货汽车 序列3=5101
--越野汽车 序列3=5102
--自卸汽车 序列3=5103
--牵引汽车 序列3=5104
--载客汽车 序列3=5105
--轿车     序列3=5106
--其中普通轿车 单位标志=1
--高级轿车     单位标志=2
--专用汽车 序列3=5107
--汽车挂车 序列3=5108
--电车    序列2=52
--摩托车  序列2=53
--非机动车辆 序列2=54
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''50'' where (国标分类号 between ''52'' and ''56'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''51'' where 序列1=''50'' and left(国标分类号0,3)=''531''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5101'' where 序列2=''51'' and left(国标分类号0,4)=''5311''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5102'' where 序列2=''51'' and left(国标分类号0,4)=''5312''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5103'' where 序列2=''51'' and left(国标分类号0,4)=''5313''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5104'' where 序列2=''51'' and left(国标分类号0,4)=''5314''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5105'' where 序列2=''51'' and left(国标分类号0,4)=''5315''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5106'' where 序列2=''51'' and left(国标分类号0,4)=''5316''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 单位标志=''1'' where 序列3=''5106'' and left(国标分类号0,6)=''531601''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 单位标志=''2'' where 序列3=''5106'' and left(国标分类号0,6)=''531605''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5107'' where 序列2=''51'' and left(国标分类号0,4)=''5317''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''5108'' where 序列2=''51'' and left(国标分类号0,4)=''5318''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''52'' where 序列1=''50'' and left(国标分类号0,3)=''532''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''53'' where 序列1=''50'' and left(国标分类号0,3)=''533''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''54'' where 序列1=''50'' and left(国标分类号0,3)=''535''')

--电器设备 序列1=60
--单价20万元（含）以上50万元以下 序列2=61
--单价50万元（含）以上100万元以下 序列2=62
--单价100万元（含）以上200万元以下 序列2=63
--单价200万元（含）以上800万元以下 序列2=64
--单价800万元（含）以上 序列2=65
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''60'' where (国标分类号 between ''60'' and ''65'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''60'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''60'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''60'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''60'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''60'' and 单价>=8000000')
--电子产品及通讯设备 序列1=70
--单价20万元（含）以上50万元以下 序列2=71
--单价50万元（含）以上100万元以下 序列2=72
--单价100万元（含）以上200万元以下 序列2=73
--单价200万元（含）以上800万元以下 序列2=74
--单价800万元（含）以上 序列2=75
--其中：电话机 序列3=7001
--传真通讯设备 序列3=7002
--台式机      序列3=7003
--便携式计算机 序列3=7004
--打印设备    序列3=7005
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''70'' where (国标分类号 between ''68'' and ''71'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''70'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''70'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''70'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''70'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''70'' and 单价>=8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''7001'' where 序列1=''70'' and left(国标分类号0,4)=''6951''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''7002'' where 序列1=''70'' and left(国标分类号0,4)=''6971''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''7003'' where 序列1=''70'' and left(国标分类号0,6)=''711701''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''7004'' where 序列1=''70'' and left(国标分类号0,6)=''711702''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列3=''7005'' where 序列1=''70'' and left(国标分类号0,4)=''7141''')

--仪器仪表、计量标准器具及量具、衡器 序列1=80
--单价20万元（含）以上50万元以下 序列2=81
--单价50万元（含）以上100万元以下 序列2=82
--单价100万元（含）以上200万元以下 序列2=83
--单价200万元（含）以上800万元以下 序列2=84
--单价800万元（含）以上 序列2=85
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''80'' where (国标分类号 between ''74'' and ''77'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''80'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''80'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''80'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''80'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''80'' and 单价>=8000000')
--文艺体育设备 序列1=90
--单价20万元（含）以上50万元以下 序列2=91
--单价50万元（含）以上100万元以下 序列2=92
--单价100万元（含）以上200万元以下 序列2=93
--单价200万元（含）以上800万元以下 序列2=94
--单价800万元（含）以上 序列2=95
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''90'' where (国标分类号 between ''80'' and ''82'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E1'' where 序列1=''90'' and 单价>=200000 and 单价<500000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E2'' where 序列1=''90'' and 单价>=500000 and 单价<1000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E3'' where 序列1=''90'' and 单价>=1000000 and 单价<2000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E4'' where 序列1=''90'' and 单价>=2000000 and 单价<8000000')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''E5'' where 序列1=''90'' and 单价>=8000000')
--图书文物及陈列品 序列1=A0
--图书资料 序列2=A1
--文物 序列2=A2
--陈列品 序列2=A3
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''A0'' where (国标分类号 between ''85'' and ''87'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''A1'' where 序列1=''A0'' and 国标分类号=''85''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''A2'' where 序列1=''A0'' and 国标分类号=''86''')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''A3'' where 序列1=''A0'' and 国标分类号=''87''')
--家具用具及其他类 序列1=B0
--其中：家具用具 序列2=B1
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列1=''B0'' where (国标分类号 between ''85'' and ''87'')')
exec('update '+@yh+'temp_资产本年增量表_按取得方式_s_zjall set 序列2=''B1'' where 序列1=''B0'' and 国标分类号=''90''')
if exists(select 1 from sysobjects where id = object_id(@yh+'资产本年增量表_按取得方式') and type='u')
begin
exec('drop table '+@yh+'资产本年增量表_按取得方式')
end

if exists(select 1 from sysobjects where name = '资产本年增量表_按取得方式') 
begin
drop table 资产本年增量表_按取得方式
end
create table 资产本年增量表_按取得方式(xh int,m1 varchar(80),m2 varchar(8),hc varchar(4),sl_1 int default 0,je_1 numeric(14,2)  default 0.00,sl_2 int default 0,je_2 numeric(14,2) default 0,sl_3 int default 0,je_3 numeric(14,2) default 0,sl_4 int default 0,je_4 numeric(14,2) default 0,sl_5 int default 0,je_5 numeric(14,2) default 0,sl_6 int default 0,je_6 numeric(14,2) default 0,sl_7 int default 0,je_7 numeric(14,2) default 0,sl_8 int default 0,je_8 numeric(14,2) default 0,sl_9 int default 0,je_9 numeric(14,2) default 0,sl_A int default 0,je_A numeric(14,2) default 0,sl_B int default 0,je_B numeric(14,2) default 0,sl_C int default 0,je_C numeric(14,2) default 0,sl_D int default 0,je_D numeric(14,2) default 0,sl_E int default 0,je_E numeric(14,2) default 0,sl_F int default 0,je_F numeric(14,2) default 0,sl_G int default 0,je_G numeric(14,2) default 0,sl_H int default 0,je_H numeric(14,2) default 0,sl_I int default 0,je_I numeric(14,2) default 0,sl_J int default 0,je_J numeric(14,2) default 0,sl_P int default 0,je_P numeric(14,2) default 0,
sl_Q int default 0,je_Q numeric(14,2) default 0,sl_R int default 0,je_R numeric(14,2) default 0,sl_S int default 0,je_S numeric(14,2) default 0,sl_T int default 0,je_T numeric(14,2) default 0,sl_U int default 0,je_U numeric(14,2) default 0,sl_V int default 0,je_V numeric(14,2) default 0,sl_W int default 0,je_W numeric(14,2) default 0,sl_X int default 0,je_X numeric(14,2) default 0,
sl_@ int default 0,je_@ numeric(14,2) default 0,sl_zj int default 0,je_zj numeric(14,2) default 0,
sl_zz int default 0,je_zz numeric(14,2) default 0,sl_jz int default 0,je_jz numeric(14,2) default 0,
sl_bj int default 0,je_bj numeric(14,2) default 0,sl_bz int default 0,je_bz numeric(14,2) default 0
)
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(1,'一、固定资产合计','00','1')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(2,'(一)土地(平方米)','10','2')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(3,'   1.生产用地（平方米）','11','3')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(4,'   2.交通邮电用地（平方米）','12','4')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(5,'   3.办公及业务用地（平方米）','13','5')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(6,'   4.市政公用设施用地（平方米）','14','6')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(7,'   5.生活及服务业用地（平方米）','15','7')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(8,'   6.科学研究用地（平方米）','16','8')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(9,'   7.文教、体育及医疗卫生用地（平方米）','17','9')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(10,'   8.特殊用地（平方米）','18','10')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(11,'   9.其他用地（平方米）','19','11')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(12,'(二)房屋构筑物（平方米）','20','12')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(13,'   1.生产用房（平方米）','21','13')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(14,'   2.交通邮电用房（平方米）','22','14')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(15,'   3.办公用房','23','15')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(16,'   4.科研、气象用房（平方米）','24','16')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(17,'   5.文化教育用房（平方米）','25','17')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(18,'   6.医疗卫生体育用房（平方米）','26','18')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(19,'   7.特殊用房（平方米）','27','19')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(20,'   8.生活、娱乐、市政公共设施、服务业用房（平方米）','28','20')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(21,'     其中：职工宿舍（平方米）','2801','21')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(22,'   9.其他用房（平方米）','29','22')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(23,'(三)通用设备（台、件、套）','30','23')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(24,'(四)专用设备（台、件、套）','40','24')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(25,'    其中：复印机（台）','41','25')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(26,'(五)交通运输设备（辆、艘、台）','50','26')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(27,'   1.汽车（辆）','51','27')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(28,'    (1)载货汽车（辆）','5101','28')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(29,'    (2)越野汽车（辆）','5102','29')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(30,'    (3)自卸汽车（辆）','5103','30')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(31,'    (4)牵引汽车（辆）','5104','31')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(32,'    (5)载客汽车（辆）','5105','32')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(33,'    (6)轿车（辆）','5106','33')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(34,'      其中：普通轿车（辆）','1','34')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(35,'            高级轿车（辆）','2','35')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(36,'    (7)专用汽车（辆）','5107','36')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(37,'    (8)汽车挂车（辆）','5108','37')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(38,'   2.电车（辆）','52','38')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(39,'   3.摩托车（辆）','53','39')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(40,'   4.非机动车辆（辆）','54','40')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(41,'(六)电器设备（台、件、套）','60','41')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(42,'(七)电子产品及通信设备（部、台、套）','70','42')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(43,'    其中：电话机（部）','7001','43')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(44,'          传真通信设备（部）','7002','44')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(45,'          台式机（台）','7003','45')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(46,'          便携式计算机（台）','7004','46')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(47,'          打印设备（台）','7005','47')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(48,'(八)仪器仪表及量具（台、套、只）','80','48')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(49,'(九)文艺体育设备（套、台、个）','90','49')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(50,'(十)图书文物及陈列品（本、卷、座、个）','A0','50')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(51,'   1.图书资料（本、卷）','A1','51')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(52,'   2.文物（座）','A2','52')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(53,'   3.陈列品（个）','A3','53')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(54,'(十一)家具及其他类（件）','B0','54')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(55,'      其中：家具用具（件）','B1','55')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(56,'二、无形资产','C0','56')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(57,'    1.专利权','C1','57')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(58,'    2.非专利技术','C2','58')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(59,'    3.商标权','C3','59')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(60,'    4.著作权','C4','60')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(61,'    5.土地使用权','C5','61')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(62,'    6.特许权','C6','62')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(63,'补充资料：','E0','63')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(64,'    1.单价20万元（含）以上设备（台、件、套）','E1','64')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(65,'    2.单价50万元（含）以上设备（台、件、套）','E2','65')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(66,'    3.单价100万元（含）以上设备（台、件、套）','E3','66')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(67,'    4.单价200万元（含）以上设备（台、件、套）','E4','67')
insert into 资产本年增量表_按取得方式(xh,m1,m2,hc) values(68,'    5.单价800万元（含）以上设备（台、件、套）','E5','68')

if exists(select 1 from sysobjects where name = 'temp_资产本年增量表_按取得方式') 
begin
drop table temp_资产本年增量表_按取得方式
end
exec('select 序列1,序列2,序列3,现状,单位标志,总价=sum(总价),总数量=sum(总数量) into temp_资产本年增量表_按取得方式 from '+@yh+'temp_资产本年增量表_按取得方式_s_zjall group by 序列1,序列2,序列3,现状,单位标志')
declare @xl1 varchar(8),@xl2 varchar(8),@xl3 varchar(8),@zj numeric(14,2),@zsl int,@xz varchar(4),@dwbz varchar(2)
while (select count(*) from temp_资产本年增量表_按取得方式)>0
begin
select top 1 @xl1=序列1,@xl2=序列2,@xl3=序列3,@xz=现状,@dwbz=单位标志,@zj=总价,@zsl=总数量 from temp_资产本年增量表_按取得方式
if @xz='1'
begin
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2='00'

end
else if @xz='2'
begin
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2='00'

end
else if @xz='3'
begin
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2='00'

end
else if @xz='4'
begin
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2='00'

end
else if @xz='5'
begin
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2='00'

end
else if @xz='6'
begin
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2='00'

end
else if @xz='7'
begin
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2='00'

end
else if @xz='8'
begin
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2='00'

end
else if @xz='9'
begin
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2='00'

end
else if @xz='A'
begin
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2='00'

end
else if @xz='B'
begin
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2='00'
end
else if @xz='C'
begin
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2='00'

end
else if @xz='D'
begin
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2='00'

end
else if @xz='E'
begin
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2='00'

end
else if @xz='F'
begin
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2='00'

end
else if @xz='G'
begin
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2='00'

end
else if @xz='H'
begin
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2='00'

end
else if @xz='I'
begin
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2='00'

end
else if @xz='J'
begin
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2='00'

end
else if @xz='P'
begin
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2='00'

end
else if @xz='Q'
begin
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2='00'

end
else if @xz='R'
begin
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2='00'

end
else if @xz='S'
begin
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2='00'

end
else if @xz='T'
begin
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2='00'

end
else if @xz='U'
begin
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2='00'
end
else if @xz='V'
begin
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2='00'

end
else if @xz='W'
begin
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2='00'

end
else if @xz='X'
begin
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2='00'
end
else if @xz='@'
begin
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2='00'

end
else if @xz='zj'
begin
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2='00'

end
else if @xz='zz'
begin
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2='00'
end
else if @xz='jz'
begin
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2='00'

end
else if @xz='bj'
begin
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2='00'

end
else if @xz='bz'
begin
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2='00'

end
else
print '现状有异常'

delete from temp_资产本年增量表_按取得方式 where 序列1=@xl1 and 序列2=@xl2 and 序列3=@xl3 and 现状=@xz and 总价=@zj and 总数量=@zsl
end
drop table temp_资产本年增量表_按取得方式
--**********************处理房屋土地构筑物
if exists(select 1 from sysobjects where name = 'temp_资产本年增量表_按取得方式_tfg') 
begin
drop table temp_资产本年增量表_按取得方式_tfg
end
exec('select 序列1,序列2,序列3,现状,单位标志,总价=sum(总价),总数量=sum(总数量) into temp_资产本年增量表_按取得方式_tfg from '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg group by 序列1,序列2,序列3,现状,单位标志')
--declare @xl1 varchar(8),@xl2 varchar(8),@xl3 varchar(8),@zj numeric(14,2),@zsl int,@xz varchar(4),@dwbz varchar(2)
while (select count(*) from temp_资产本年增量表_按取得方式_tfg)>0
begin
select top 1 @xl1=序列1,@xl2=序列2,@xl3=序列3,@xz=现状,@dwbz=单位标志,@zj=总价,@zsl=总数量 from temp_资产本年增量表_按取得方式_tfg
if @xz='1'
begin
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_1=sl_1+@zsl,je_1=je_1+@zj where m2='00'

end
else if @xz='2'
begin
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_2=sl_2+@zsl,je_2=je_2+@zj where m2='00'

end
else if @xz='3'
begin
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_3=sl_3+@zsl,je_3=je_3+@zj where m2='00'

end
else if @xz='4'
begin
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_4=sl_4+@zsl,je_4=je_4+@zj where m2='00'

end
else if @xz='5'
begin
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_5=sl_5+@zsl,je_5=je_5+@zj where m2='00'

end
else if @xz='6'
begin
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_6=sl_6+@zsl,je_6=je_6+@zj where m2='00'

end
else if @xz='7'
begin
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_7=sl_7+@zsl,je_7=je_7+@zj where m2='00'

end
else if @xz='8'
begin
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_8=sl_8+@zsl,je_8=je_8+@zj where m2='00'

end
else if @xz='9'
begin
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_9=sl_9+@zsl,je_9=je_9+@zj where m2='00'

end
else if @xz='A'
begin
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_A=sl_A+@zsl,je_A=sl_A+@zj where m2='00'

end
else if @xz='B'
begin
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_B=sl_B+@zsl,je_B=je_B+@zj where m2='00'
end
else if @xz='C'
begin
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_C=sl_C+@zsl,je_C=je_C+@zj where m2='00'

end
else if @xz='D'
begin
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_D=sl_D+@zsl,je_D=je_D+@zj where m2='00'

end
else if @xz='E'
begin
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_E=sl_E+@zsl,je_E=je_E+@zj where m2='00'

end
else if @xz='F'
begin
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_F=sl_F+@zsl,je_F=sl_F+@zj where m2='00'

end
else if @xz='G'
begin
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_G=sl_G+@zsl,je_G=je_G+@zj where m2='00'

end
else if @xz='H'
begin
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_H=sl_H+@zsl,je_H=je_H+@zj where m2='00'

end
else if @xz='I'
begin
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_I=sl_I+@zsl,je_I=je_I+@zj where m2='00'

end
else if @xz='J'
begin
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_J=sl_J+@zsl,je_J=je_J+@zj where m2='00'

end
else if @xz='P'
begin
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_P=sl_P+@zsl,je_P=je_P+@zj where m2='00'

end
else if @xz='Q'
begin
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_Q=sl_Q+@zsl,je_Q=je_Q+@zj where m2='00'

end
else if @xz='R'
begin
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_R=sl_R+@zsl,je_R=je_R+@zj where m2='00'

end
else if @xz='S'
begin
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_S=sl_S+@zsl,je_S=je_S+@zj where m2='00'

end
else if @xz='T'
begin
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_T=sl_T+@zsl,je_T=je_T+@zj where m2='00'

end
else if @xz='U'
begin
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_U=sl_U+@zsl,je_U=je_U+@zj where m2='00'
end
else if @xz='V'
begin
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_V=sl_V+@zsl,je_V=je_V+@zj where m2='00'

end
else if @xz='W'
begin
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_W=sl_W+@zsl,je_W=je_W+@zj where m2='00'

end
else if @xz='X'
begin
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_X=sl_X+@zsl,je_X=je_X+@zj where m2='00'
end
else if @xz='@'
begin
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_@=sl_@+@zsl,je_@=je_@+@zj where m2='00'

end
else if @xz='zj'
begin
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_zj=sl_zj+@zsl,je_zj=je_zj+@zj where m2='00'

end
else if @xz='zz'
begin
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_zz=sl_zz+@zsl,je_zz=je_zz+@zj where m2='00'
end
else if @xz='jz'
begin
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_jz=sl_jz+@zsl,je_jz=je_jz+@zj where m2='00'

end
else if @xz='bj'
begin
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_bj=sl_bj+@zsl,je_bj=je_bj+@zj where m2='00'

end
else if @xz='bz'
begin
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl1
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl2
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@xl3
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2=@dwbz
update 资产本年增量表_按取得方式 set sl_bz=sl_bz+@zsl,je_bz=je_bz+@zj where m2='00'

end
else
print '现状有异常'

delete from temp_资产本年增量表_按取得方式_tfg where 序列1=@xl1 and 序列2=@xl2 and 序列3=@xl3 and 现状=@xz and 总价=@zj and 总数量=@zsl
end
drop table temp_资产本年增量表_按取得方式_tfg

--**************************
exec('drop table '+@yh+'temp_资产本年增量表_按取得方式_s_zjall')
exec('drop table '+@yh+'temp_资产本年增量表_按取得方式_s_zjall_tfg')


