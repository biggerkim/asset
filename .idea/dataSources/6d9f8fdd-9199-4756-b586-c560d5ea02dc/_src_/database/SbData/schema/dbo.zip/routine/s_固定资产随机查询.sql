CREATE procedure s_固定资产随机查询 @qsrq smalldatetime,@jzrq smalldatetime,@lydw varchar(10),@yh varchar(50)
as
if @lydw='00'
begin
set @lydw=''
end

--**************************************************
if exists(select 1 from sysobjects where id = object_id(@yh+'temp_RandomSearch') and type='u')
exec('drop table '+@yh+'temp_RandomSearch')
else 
print '没有 '+@yh+'temp_RandomSearch'

if exists(select 1 from sysobjects where name = 'temp_RandomSearch') 
drop table temp_RandomSearch
else 
print '没有 temp_RandomSearch'
exec('select * into '+@yh+'temp_RandomSearch from (
--目前在帐设备
--本期在帐数(非年末数，本期增加)
SELECT * FROM S_ZJALL WHERE 入库时间>='''+@qsrq+''' AND 入库时间<='''+@jzrq+'''
) b')
