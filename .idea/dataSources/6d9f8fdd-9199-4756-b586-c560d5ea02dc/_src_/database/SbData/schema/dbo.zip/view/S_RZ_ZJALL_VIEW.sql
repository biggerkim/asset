CREATE VIEW dbo.S_RZ_ZJALL_VIEW
AS
SELECT dbo.S_RZ_ZJALL.领用单位号, dbo.S_RZ_ZJALL.仪器编号, 
      dbo.S_RZ_ZJALL.仪器名称, dbo.S_RZ_ZJALL.型号, dbo.S_RZ_ZJALL.规格, 
      dbo.S_RZ_ZJALL.单价, dbo.S_RZ_ZJALL.厂家, dbo.S_RZ_ZJALL.出厂号, 
      dbo.S_RZ_ZJALL.出厂日期, dbo.S_RZ_ZJALL.购置日期, 
      dbo.S_RZ_ZJALL.存放地名称, dbo.S_RZ_ZJALL.领用人, dbo.S_RZ_ZJALL.经手人, 
      dbo.S_RZ_ZJALL.输入人, dbo.S_RZ_ZJALL.记帐人, dbo.S_RZ_ZJALL.单据号, 
      dbo.S_RZ_ZJALL.存放地编号, dbo.S_RZ_ZJALL.国标分类号, 
      dbo.S_RZ_ZJALL.分类号, dbo.S_RZ_ZJALL.备注, dbo.S_RZ_ZJALL.修改日期, 
      dbo.S_RZ_ZJALL.IP地址, dbo.S_RZ_ZJALL.修改人, dbo.S_RZ_ZJALL.RZID, 
      dbo.S_JFKM.经费科目名, dbo.S_SYFX.使用方向名, dbo.S_SBLY.设备来源名, 
      dbo.S_XZ.现状名, dbo.S_RZ_ZJALL.现状, dbo.S_RZ_ZJALL.经费科目, 
      dbo.S_RZ_ZJALL.使用方向, dbo.S_RZ_ZJALL.设备来源
FROM dbo.S_RZ_ZJALL LEFT OUTER JOIN
      dbo.S_JFKM ON dbo.S_RZ_ZJALL.经费科目 = dbo.S_JFKM.code LEFT OUTER JOIN
      dbo.S_SYFX ON dbo.S_RZ_ZJALL.使用方向 = dbo.S_SYFX.code LEFT OUTER JOIN
      dbo.S_SBLY ON dbo.S_RZ_ZJALL.设备来源 = dbo.S_SBLY.code LEFT OUTER JOIN
      dbo.S_XZ ON dbo.S_RZ_ZJALL.现状 = dbo.S_XZ.code
